#!/bin/bash
set -e
clear

echo "===================================================================="
echo "                     Alternix Desktop Installer"
echo "                         (Devuan Edition)"
echo "===================================================================="
echo "           --------> Teaching Penguins to fly! <--------"
echo " "
echo "--------------------------------------------------------------------"
echo ""
echo " Setup can take a while, be sure to have a cuppa & some good music!"
echo ""
echo "--------------------------------------------------------------------"
echo ""
echo ""


SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
if [ -d "$SCRIPT_DIR/Alternix" ]; then
    ALT_ROOT="$SCRIPT_DIR"
else
    ALT_ROOT="$HOME/Alternix"
fi

if [ ! -d "$ALT_ROOT" ]; then
    echo "ERROR: $ALT_ROOT not found. Please place install.sh inside ~/Alternix."
    exit 1
fi

# This script runs both for the ISO's prebuilt preview and for normal
# installations. The prebuilt image cannot enrol a unique pattern/PIN while
# running non-interactively inside live-build's chroot.
ALT_IS_LIVE_BUILD=0
if [ "${ALTERNIX_ISO_PREBUILD:-0}" = 1 ] || [ -e /etc/debian_chroot ]; then
    ALT_IS_LIVE_BUILD=1
elif [ -e /proc/1/root ]; then
    # live-build bind-mounts /proc into its chroot. PID 1 belongs to the
    # build host, whose root has a different device/inode than this chroot.
    # /etc/debian_chroot is not guaranteed to survive every build hook.
    ALT_PID1_ROOT="$(stat -Lc '%d:%i' /proc/1/root 2>/dev/null || true)"
    ALT_CURRENT_ROOT="$(stat -Lc '%d:%i' / 2>/dev/null || true)"
    if [ -n "$ALT_PID1_ROOT" ] && [ -n "$ALT_CURRENT_ROOT" ] && \
       [ "$ALT_PID1_ROOT" != "$ALT_CURRENT_ROOT" ]; then
        ALT_IS_LIVE_BUILD=1
    fi
fi

# Detect an incomplete Git checkout before any costly package installation.
# The ISO hook clones AlternixDE anew: files that only exist in a local working
# tree are NOT available to it until they are committed and pushed.
for auth_source in \
    "$ALT_ROOT/Alternix/apps/alternix-auth-setup.sh" \
    "$ALT_ROOT/Alternix/apps/alternix-auth.c" \
    "$ALT_ROOT/Alternix/apps/osm-lock.cpp"; do
    if [ ! -f "$auth_source" ]; then
        echo "ERROR: Required Alternix authentication source is missing: $auth_source" >&2
        echo "Add the source to the AlternixDE repository and push it before rebuilding the ISO." >&2
        exit 1
    fi
done

# Date & Time is a separate Settings module. Both sources must be present
# before package installation or an ISO build starts.
for settings_source in \
    "$ALT_ROOT/Alternix/apps/osm-settings/location.cpp" \
    "$ALT_ROOT/Alternix/apps/osm-settings/date-time.cpp" \
    "$ALT_ROOT/Alternix/apps/osm-settings/osm-settings.cpp"; do
    if [ ! -s "$settings_source" ]; then
        echo "ERROR: Required Settings source is missing: $settings_source" >&2
        echo "Add the new Date & Time module to AlternixDE before building the ISO." >&2
        exit 1
    fi
done

# The audio hardware installer is an existing AlternixDE source, not a
# downloaded repair patch. Missing sources must fail BEFORE a long ISO build.
ALT_AUDIO_SOURCE="$ALT_ROOT/Alternix/scripts/alternix-audio-fix.sh"
if [ ! -s "$ALT_AUDIO_SOURCE" ] || ! bash -n "$ALT_AUDIO_SOURCE"; then
    echo "ERROR: Missing or invalid audio setup source: $ALT_AUDIO_SOURCE" >&2
    echo "Commit alternix-audio-fix.sh under Alternix/scripts in the AlternixDE checkout." >&2
    exit 1
fi

# Verify the complete X11 pen, touch and auto-rotation runtime before an
# ISO build/update begins. These files belong in AlternixDE, not in the
# installer directory. Refuse to ship a UI with missing backends.
# Wallpaper rotation must ship as ONE consistent set of sources. The Qtile
# event hook is in the repository config (not in Alternix/scripts/), while
# the existing wallpaper restorer is in Alternix/apps/.
ALT_PAPER_RESTORE_SOURCE="$ALT_ROOT/Alternix/apps/osm-paper-restore"
ALT_PAPER_QTILE_SOURCE="$ALT_ROOT/Alternix/configs/qtile/config.py"
if [ ! -s "$ALT_PAPER_RESTORE_SOURCE" ] || \
   [ ! -s "$ALT_PAPER_QTILE_SOURCE" ] || \
   ! grep -Fq -- '--clear' "$ALT_PAPER_RESTORE_SOURCE" || \
   ! grep -Fq 'Alternix wallpaper refresh after XRandR/Qtile reconfiguration' "$ALT_PAPER_QTILE_SOURCE"; then
    echo "ERROR: Wallpaper rotation sources are missing/outdated in Alternix/apps or Alternix/configs/qtile." >&2
    exit 1
fi
if ! python3 - "$ALT_PAPER_RESTORE_SOURCE" "$ALT_PAPER_QTILE_SOURCE" <<'ALT_PAPER_SYNTAX'
import ast
import pathlib
import sys
for filename in sys.argv[1:]:
    ast.parse(pathlib.Path(filename).read_text(encoding='utf-8'), filename=filename)
ALT_PAPER_SYNTAX
then
    echo "ERROR: Wallpaper restoration/Qtile Python source failed syntax validation." >&2
    exit 1
fi

ALT_INPUT_SOURCE_DIR="$ALT_ROOT/Alternix/scripts"
for alt_input_file in \
    alternix-rotate-monitor.sh \
    alternix-rotate-setup.sh \
    alternix-rotate-toggle.sh \
    alternix-stylus-apply.sh; do
    if [ ! -s "$ALT_INPUT_SOURCE_DIR/$alt_input_file" ] || \
       ! bash -n "$ALT_INPUT_SOURCE_DIR/$alt_input_file"; then
        echo "ERROR: Missing or invalid Alternix pen/rotation source: $ALT_INPUT_SOURCE_DIR/$alt_input_file" >&2
        echo "Add the complete updated scripts to Alternix/scripts before installing." >&2
        exit 1
    fi
done
# Faster sensor loop: prevent restoring the old 1-second debounce code.
if ! grep -Fq 'FAST_ROTATION_V2' "$ALT_INPUT_SOURCE_DIR/alternix-rotate-monitor.sh"; then
    echo 'ERROR: Add the updated fast auto-rotation backend to Alternix/scripts before installing.' >&2
    exit 1
fi
# Refuse outdated gesture and input sources: earlier versions silently read
# XRandR's SUPPORTED orientations as "normal" even while rotated.
if ! grep -Fq 'The active rotation follows the geometry' \
        "$ALT_INPUT_SOURCE_DIR/alternix-rotate-monitor.sh" || \
   ! grep -Fq '    restart)' "$ALT_INPUT_SOURCE_DIR/alternix-rotate-toggle.sh"; then
    echo 'ERROR: Install the latest complete rotation monitor and controller in Alternix/scripts.' >&2
    exit 1
fi
# These three launch helpers are stored in the repository's Alternix/scripts,
# not alongside this installer or in Alternix/apps. Check them before changing
# the installed system; a failed copy must never look like a completed update.
for alt_layer_script in alternix-touchscroll.py alternix-waydroid-session alternix-exe; do
    if [ ! -s "$ALT_INPUT_SOURCE_DIR/$alt_layer_script" ]; then
        echo "ERROR: Required Alternix script missing: $ALT_INPUT_SOURCE_DIR/$alt_layer_script" >&2
        exit 1
    fi
done

# Qt/Xlib compatibility: the overlay sources must import Xlib only AFTER
# Qt headers. Xlib's Status/None macros otherwise cause hundreds of Qt5
# compile errors on Devuan Excalibur. Detect stale source BEFORE building.
for alt_x11_overlay in osm-status.cpp osm-notify.cpp; do
    alt_x11_src="$ALT_ROOT/Alternix/apps/$alt_x11_overlay"
    if [ -s "$alt_x11_src" ] && ! grep -Fq '#  undef Status' "$alt_x11_src"; then
        echo "ERROR: $alt_x11_src is the old Xlib/Qt header-conflicting version." >&2
        echo "Replace it with the supplied rotation-aware source before building." >&2
        exit 1
    fi
done

for alt_input_ui in osm-running.cpp osm-status.cpp osm-notify.cpp; do
    if [ ! -s "$ALT_ROOT/Alternix/apps/$alt_input_ui" ] || \
       ! grep -Fq 'alternixActiveScreenGeometry' "$ALT_ROOT/Alternix/apps/$alt_input_ui"; then
        echo "ERROR: Missing rotation-aware gesture source: Alternix/apps/$alt_input_ui" >&2
        exit 1
    fi
done

if [ ! -s "$ALT_ROOT/Alternix/apps/osm-settings/display.cpp" ] || \
   ! grep -Fq 'alternix-stylus-apply.sh' "$ALT_ROOT/Alternix/apps/osm-settings/display.cpp"; then
    echo "ERROR: Updated Display settings source with stylus controls is missing." >&2
    exit 1
fi

# Alternix VLC: require the FULL native Qt interface theme before the install.
# No .vlt files or separate patch/repair commands are used.
ALT_VLC_THEME_SRC="$ALT_ROOT/Alternix/themes/vlc"
for vlc_asset in \
    "$ALT_VLC_THEME_SRC/Kvantum/AlternixVLC/AlternixVLC.svg" \
    "$ALT_VLC_THEME_SRC/Kvantum/AlternixVLC/AlternixVLC.kvconfig" \
    "$ALT_VLC_THEME_SRC/qt5-style/alternixvlcstyle.cpp" \
    "$ALT_VLC_THEME_SRC/qt5-style/alternixvlcstyle.json" \
    "$ALT_VLC_THEME_SRC/icons/play_up.png" \
    "$ALT_VLC_THEME_SRC/icons/pause_up.png"; do
    if [ ! -s "$vlc_asset" ]; then
        echo "ERROR: Required Alternix VLC theme asset not found: $vlc_asset" >&2
        echo "Commit Alternix/themes/vlc from the supplied repository assets first." >&2
        exit 1
    fi
done

# Welcome: ship the complete native Qt5 source and launcher icon in the
# repository. Do not silently install a first-boot guide with missing assets.
ALT_WELCOME_SOURCE="$ALT_ROOT/Alternix/apps/welcome.cpp"
ALT_WELCOME_ICON="$ALT_ROOT/Alternix/icons/welcome.png"
if [ ! -s "$ALT_WELCOME_SOURCE" ] || [ ! -s "$ALT_WELCOME_ICON" ]; then
    echo "ERROR: Welcome requires Alternix/apps/welcome.cpp and Alternix/icons/welcome.png." >&2
    exit 1
fi

# Ask for username
while true; do
    read -rp "Enter the username for Alternix: " TARGET_USER

    # Basic validation
    if [[ "$TARGET_USER" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
        break
    else
        echo "Invalid username. Use only lowercase letters, digits, hyphens, and underscores."
    fi
done

# Check if user exists
if id "$TARGET_USER" >/dev/null 2>&1; then
    echo "User '$TARGET_USER' already exists. Skipping creation."
else
    echo "Creating user '$TARGET_USER'..."
    sudo useradd -m -s /bin/bash "$TARGET_USER"
    echo "User '$TARGET_USER' created."
fi


# Add to sudo (optional)
if ! groups "$TARGET_USER" | grep -q "\bsudo\b"; then
    echo "Adding '$TARGET_USER' to sudo group..."
    sudo usermod -aG sudo "$TARGET_USER"
fi

# Grant NOPASSWD now, up front — the rest of this script makes dozens of
# sudo calls (package installs, config copies, app builds/moves). Without
# this, the sudo credential cache expires mid-script (default 15 min) and
# a later sudo call fails silently under `set -e`, aborting the install
# partway through with no clear error.
echo "Setting temporary installation-only sudo permissions for $TARGET_USER..."
echo "$TARGET_USER ALL=(ALL) NOPASSWD: ALL" | sudo tee /etc/sudoers.d/alternix-nopasswd >/dev/null
sudo chmod 440 /etc/sudoers.d/alternix-nopasswd
# Fail closed: if this installer aborts, never leave its temporary
# passwordless rule active on a partly-installed system.
ALT_TEMP_NP_ACTIVE=1
ALT_AUTH_STAGE=""
alternix_installer_exit_cleanup() {
    local code=$?
    if [ -n "${ALT_AUTH_STAGE:-}" ] && [ -d "$ALT_AUTH_STAGE" ]; then
        /usr/bin/sudo /bin/rm -rf -- "$ALT_AUTH_STAGE" || true
    fi
    if [ "$ALT_TEMP_NP_ACTIVE" = 1 ]; then
        /usr/bin/sudo /bin/rm -f /etc/sudoers.d/alternix-nopasswd || true
    fi
    return "$code"
}
trap alternix_installer_exit_cleanup EXIT

echo ""
# Always use the selected account's actual home for user configuration,
# even if the ISO build/installer itself is running as root.
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
TARGET_GROUP="$(id -gn "$TARGET_USER")"
if [ -z "$TARGET_HOME" ] || [ ! -d "$TARGET_HOME" ]; then
    echo "ERROR: Could not locate home directory for user '$TARGET_USER'."
    exit 1
fi
as_target() { sudo -u "$TARGET_USER" -H "$@"; }

echo "User setup complete. Username set to: $TARGET_USER"
echo "• User home: $TARGET_HOME"
echo "• Build source: $ALT_ROOT"
echo ""




# ────────────────────────────────────────────────
# 1. Install apps & dependencies
# ────────────────────────────────────────────────
echo "[1/10] Installing system dependencies..."

echo "[System] Updating APT package lists.."
sudo apt update

echo "[System] Installing XLibre.."
sudo apt install -y ca-certificates curl

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://xlibre-deb.github.io/key.asc | sudo tee /etc/apt/keyrings/xlibre-deb.asc
sudo chmod a+r /etc/apt/keyrings/xlibre-deb.asc

# Use the dedicated Devuan repo — Devuan codenames used directly
DEVUAN_CODENAME=$(. /etc/os-release && echo "$VERSION_CODENAME")
ARCH=$(dpkg --print-architecture)
echo "[System] Installing XLibre for Devuan '$DEVUAN_CODENAME'..."
sudo tee /etc/apt/sources.list.d/xlibre-deb.sources > /dev/null << XLIBRESRC
Types: deb deb-src
URIs: https://xlibre-deb.github.io/devuan/
Suites: ${DEVUAN_CODENAME}
Components: main
Architectures: ${ARCH}
Signed-By: /etc/apt/keyrings/xlibre-deb.asc
XLIBRESRC

sudo apt update
# Install Alacritty before the X server, so any x-terminal-emulator
# dependency can be satisfied without pulling in xterm.
sudo apt install -y alacritty

# ────────────────────────────────────────────────
# AlternixOS terminal policy: keep xterm/uxterm out of future APT operations.
# uxterm is shipped by the same Debian/Devuan package as xterm.
# This preference blocks xterm without blocking the x-terminal-emulator
# virtual package, which Alacritty provides.
# ────────────────────────────────────────────────
echo "[Terminal] Blocking xterm/uxterm from future APT installations..."
sudo install -d -m 0755 /etc/apt/preferences.d
sudo tee /etc/apt/preferences.d/alternix-no-xterm.pref >/dev/null <<'ALT_NO_XTERM'
Package: xterm
Pin: version *
Pin-Priority: -1
ALT_NO_XTERM


sudo apt install xlibre -y
# XLibre-safe tablet/pen stack. xinput and xrandr must be present for
# display mapping; monitor-sensor comes from iio-sensor-proxy. Do not pull in
# the Xorg Wacom driver on an XLibre session (its server ABI may differ).
echo "[Input] Installing touchscreen, Wacom and rotation dependencies..."
sudo apt-get install -y xinput x11-xserver-utils iio-sensor-proxy dbus-x11
if apt-cache policy xserver-xlibre-input-wacom 2>/dev/null | \
   grep -Eq '^[[:space:]]*Candidate:[[:space:]]*[^ (]'; then
    if ! sudo apt-get install -y xserver-xlibre-input-wacom; then
        echo "WARNING: XLibre Wacom driver installation failed; libinput pens remain supported." >&2
    fi
else
    echo "[Input] No xserver-xlibre-input-wacom candidate in configured repositories; using XLibre libinput." 
fi

#sudo dpkg --add-architecture i386

# Nala is required by os-check-update. Devuan Excalibur includes Nala
# through its merged package repositories, so use the distribution's APT
# package rather than adding and then removing an external Volian source.
# A failed install must be visible: otherwise the ISO builds successfully
# but its System Update application cannot update the system.
echo "[System] Installing Nala (required by System Update).."

if ! dpkg-query -W -f='${Status}' nala 2>/dev/null | grep -qx 'install ok installed' || \
   ! command -v nala >/dev/null 2>&1 || ! nala --version >/dev/null 2>&1; then
    if ! sudo apt-get install -y nala; then
        echo "ERROR: Could not install Nala from the configured Devuan APT sources."
        echo "Check the APT errors above. Package candidate information:"
        apt-cache policy nala || true
        exit 1
    fi
fi

# Do not continue building an ISO that lacks a working Nala executable.
if ! dpkg-query -W -f='${Status}' nala 2>/dev/null | grep -qx 'install ok installed' || \
   ! command -v nala >/dev/null 2>&1 || ! nala --version >/dev/null 2>&1; then
    echo "ERROR: Nala is missing or cannot start after installation."
    echo "The System Update application requires a working Nala installation."
    exit 1
fi

echo "[System] Nala installed and verified: $(nala --version)"

echo "[System] Installing Required Components.."
sudo apt install -y \
    build-essential libssl-dev git qtbase5-dev qt5-qmake qtdeclarative5-dev xdg-utils cmake g++\
    fonts-noto-color-emoji libxcomposite-dev libxrender-dev libxfixes-dev fonts-freefont-ttf \
    xwallpaper pkg-config libpoppler-qt5-dev htop python3-pip python3-lxml fonts-urw-base35 \
    python3-venv qtile python3-cffi python3-xcffib picom redshift onboard fake-hwclock libcamera-ipa\
    samba xdotool alacritty sqlite3 fuse libmbim-utils libqmi-utils modemmanager libcamera-tools \
    synaptic brightnessctl pavucontrol pulseaudio alsa-utils mpg123 flatpak libevdev-dev \
    elogind libpam-elogind xserver-xlibre-input-libinput ssh mobile-broadband-provider-info \
    xprintidle libx11-dev libxtst-dev ntfs-3g aria2 x11-apps zip iio-sensor-proxy wmctrl \
    kalk vlc qt5-style-kvantum thermald network-manager aptitude timeshift tlp fonts-ubuntu \
    python3-yaml python3-dateutil python3-pyqt5 python3-packaging python3-requests bluez \
    podman podman-compose gvfs gvfs-backends gvfs-fuse gvfs-daemons fuse3 dbus-x11 libxi-dev \
    sysvinit-utils pm-utils ntfs-3g exfatprogs exfat-fuse udisks2 pmount libxext-dev timeshift




# Reuse the installer's existing ISO/chroot detection. Freshclam is allowed to
# download definitions into the image, but never manipulates the build host.
ALT_CLAMAV_BUILD_CHROOT="$ALT_IS_LIVE_BUILD"
# ────────────────────────────────────────────────
# AlternixOS Security: ClamAV on-demand malware scanner
# - APT selects its signed native package for the detected architecture.
# - No external .deb downloads, GitHub binaries or added Debian repositories.
# - clamscan is used by Settings -> Security; clamd is not required.
# - freshclam provides automatic malware-definition updates on SysVinit.
# ────────────────────────────────────────────────
echo "[Security] Installing/updating ClamAV for $(dpkg --print-architecture)..."
if ! sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        clamav clamav-freshclam; then
    echo "ERROR: ClamAV packages could not be installed from the configured Devuan repositories." >&2
    apt-cache policy clamav clamav-freshclam || true
    exit 1
fi

if ! dpkg-query -W -f='${Status}' clamav 2>/dev/null | grep -qx 'install ok installed' || \
   ! dpkg-query -W -f='${Status}' clamav-freshclam 2>/dev/null | grep -qx 'install ok installed' || \
   ! command -v clamscan >/dev/null 2>&1 || ! command -v freshclam >/dev/null 2>&1; then
    echo "ERROR: ClamAV installation did not provide both clamscan and freshclam." >&2
    exit 1
fi

# Only the definition updater is a service. On-demand file scans don't run
# permanently, reducing resource use on older tablets and laptops.
if [ -x /etc/init.d/clamav-freshclam ]; then
    sudo update-rc.d clamav-freshclam defaults >/dev/null
    sudo update-rc.d clamav-freshclam enable >/dev/null
else
    echo "WARNING: ClamAV freshclam SysVinit script is missing; automatic signature updates may not run." >&2
fi

# Full signature databases can be large. Seed a new image/installation so the
# scanner can work offline after installation; don't redownload existing
# databases every time the updater is run. freshclam checks for newer releases
# automatically via its SysVinit service once the installed OS is running.
alt_clamav_database_ready() {
    local main_ok=0 daily_ok=0
    for db in /var/lib/clamav/main.cvd /var/lib/clamav/main.cld; do
        [ ! -s "$db" ] || main_ok=1
    done
    for db in /var/lib/clamav/daily.cvd /var/lib/clamav/daily.cld; do
        [ ! -s "$db" ] || daily_ok=1
    done
    [ "$main_ok" = 1 ] && [ "$daily_ok" = 1 ]
}

# Freshclam's manual and daemon modes must not share a live database lock.
# Never start/stop the *host's* services from an ISO-build chroot.
if ! alt_clamav_database_ready; then
    echo "[Security] Downloading initial ClamAV virus definitions..."
    if [ "${ALT_CLAMAV_BUILD_CHROOT:-0}" != 1 ] && [ -x /etc/init.d/clamav-freshclam ]; then
        sudo service clamav-freshclam stop >/dev/null 2>&1 || true
    fi
    if ! sudo timeout 900 freshclam --stdout; then
        echo "WARNING: Initial virus-definition download failed (network/CDN issue)." >&2
        echo "WARNING: freshclam will retry automatically when the installed OS is online." >&2
    fi
fi

if [ "${ALT_CLAMAV_BUILD_CHROOT:-0}" != 1 ] && [ -x /etc/init.d/clamav-freshclam ]; then
    if ! sudo service clamav-freshclam restart; then
        echo "WARNING: Unable to start the ClamAV definition-update service now; it is enabled at boot." >&2
    fi
else
    echo "[Security] ISO build: freshclam enabled for installed-system boot; no live services started."
fi

if alt_clamav_database_ready; then
    echo "[Security] ClamAV signature databases are ready."
else
    echo "WARNING: ClamAV is installed but its main/daily signatures are not yet ready." >&2
    echo "WARNING: Scans require freshclam to finish downloading signatures." >&2
fi

echo "[Security] Installed $(clamscan --version | head -n 1)"

# ------------------------------------------------
# AlternixOS clock stability (Devuan / SysVinit)
# Chrony corrects running-clock drift; util-linux-extra supplies hwclock.
# Do not change the configured timezone or RTC UTC/LOCAL setting.
# ------------------------------------------------
echo "[System] Configuring automatic time synchronisation..."
sudo apt install -y chrony util-linux-extra

# Configure Chrony even when this installer is run inside the ISO build chroot.
# Keep any existing servers, authentication and RTC configuration intact.
sudo /bin/sh <<'ALT_TIME_CONFIG'
set -eu
CONF=/etc/chrony/chrony.conf
mkdir -p /etc/chrony /var/lib/chrony
if [ ! -f "$CONF" ]; then
    cat > "$CONF" <<'EOF'
pool pool.ntp.org iburst
driftfile /var/lib/chrony/chrony.drift
makestep 1.0 3
rtcsync
EOF
else
    grep -Eq '^[[:space:]]*(pool|server|peer|refclock)[[:space:]]+' "$CONF" || \
        printf '\n# AlternixOS: time sources\npool pool.ntp.org iburst\n' >> "$CONF"
    grep -Eq '^[[:space:]]*driftfile[[:space:]]+' "$CONF" || \
        printf '\n# AlternixOS: clock drift calibration\ndriftfile /var/lib/chrony/chrony.drift\n' >> "$CONF"
    grep -Eq '^[[:space:]]*makestep[[:space:]]+' "$CONF" || \
        printf '\n# AlternixOS: correct large startup errors\nmakestep 1.0 3\n' >> "$CONF"
    if ! grep -Eq '^[[:space:]]*(rtcfile|rtcsync)([[:space:]]|$)' "$CONF"; then
        printf '\n# AlternixOS: update hardware RTC after synchronisation\nrtcsync\n' >> "$CONF"
    fi
fi

# Enable Chrony for subsequent boots (works with SysVinit, not systemctl).
if command -v update-rc.d >/dev/null 2>&1; then
    update-rc.d chrony defaults >/dev/null 2>&1 || true
    update-rc.d chrony enable >/dev/null 2>&1 || true
fi

# RTC checks have to run on the installed machine, not the ISO build host.
# Keep fake-hwclock for devices whose RTC cannot actually be read.
cat > /etc/init.d/alternix-rtc-check <<'EOF'
#!/bin/sh
### BEGIN INIT INFO
# Provides:          alternix-rtc-check
# Required-Start:    $local_fs
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: Prefer a usable hardware RTC over fake-hwclock
### END INIT INFO
case "${1:-}" in
    start)
        if command -v hwclock >/dev/null 2>&1 && hwclock --show >/dev/null 2>&1; then
            if [ -x /etc/init.d/fake-hwclock ] && command -v update-rc.d >/dev/null 2>&1; then
                update-rc.d fake-hwclock disable >/dev/null 2>&1 || true
            fi
        fi
        ;;
    stop|restart|force-reload) ;;
esac
exit 0
EOF
chmod 755 /etc/init.d/alternix-rtc-check
if command -v update-rc.d >/dev/null 2>&1; then
    update-rc.d alternix-rtc-check defaults 99 >/dev/null 2>&1 || true
fi
ALT_TIME_CONFIG

# Avoid starting daemons and probing RTC devices inside an ISO-build chroot.
ALT_TIME_ROOT_ID="$(sudo stat -Lc '%d:%i' / 2>/dev/null || true)"
ALT_TIME_INIT_ROOT_ID="$(sudo stat -Lc '%d:%i' /proc/1/root/ 2>/dev/null || true)"
if [ ! -e /etc/debian_chroot ] && \
   [ -n "$ALT_TIME_INIT_ROOT_ID" ] && \
   [ "$ALT_TIME_ROOT_ID" = "$ALT_TIME_INIT_ROOT_ID" ]; then
    sudo service chrony restart || echo "WARNING: Chrony will start automatically at next boot."
else
    echo "[Time] Chrony enabled for the installed system; live checks deferred until boot."
fi

# ------------------------------------------------
# AlternixOS clock actions: osm-sudo pattern authentication + a fixed helper.
# The helper cannot run arbitrary commands and requires no CLI sudo password.
# ------------------------------------------------
echo "[Time] Configuring osm-sudo clock permissions..."
sudo install -d -m 0755 /usr/local/sbin
sudo /bin/sh -c 'cat > /usr/local/sbin/alternix-time-helper' <<'ALT_TIME_HELPER_CONTENT'
#!/bin/sh
# Installed by AlternixOS. Root-owned and callable only for specific clock actions.
# There is intentionally NO arbitrary command, shell, or file argument interface.
PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH
umask 022

if [ "$(id -u)" -ne 0 ]; then
    echo "TIME_HELPER_DENIED: elevated privileges were not granted"
    exit 1
fi

case "${1:-}" in
    status)
        [ "$#" -eq 1 ] || exit 2
        echo TIME_HELPER_READY
        exit 0
        ;;
    set|network-set)
        [ "$#" -eq 2 ] || { echo "Invalid clock request"; exit 2; }
        # Only accept a numeric Unix timestamp; never evaluate shell input.
        printf '%s\n' "$2" | LC_ALL=C grep -Eq '^[0-9]{9,11}(\.[0-9]{1,3})?$' || {
            echo "Invalid clock timestamp"; exit 2;
        }
        YEAR=$(date -u -d "@$2" +%Y 2>/dev/null) || {
            echo "Invalid clock timestamp"; exit 2;
        }
        [ "$YEAR" -ge 2000 ] && [ "$YEAR" -le 2099 ] || {
            echo "Timestamp outside supported range"; exit 2;
        }
RTCLOG=""
FAKELOG=""
RTC_PRESENT=0
HW=""
RTC_MODE=UTC
[ -f /etc/adjtime ] && [ "$(sed -n '3p' /etc/adjtime 2>/dev/null)" = LOCAL ] && RTC_MODE=LOCAL

rtc_detect() {
  for r in /sys/class/rtc/rtc*; do
    [ -d "$r" ] || continue
    RTC_PRESENT=1
    RTCLOG="$RTCLOG
Detected $r ($(cat "$r/name" 2>/dev/null))"
  done
  for r in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$r" ] && RTC_PRESENT=1
  done
  [ -r /proc/driver/rtc ] && RTC_PRESENT=1
  RTCLOG="$RTCLOG
RTC time scale from /etc/adjtime: $RTC_MODE"
}

rtc_readback_ok() {
  for r in /sys/class/rtc/rtc*; do
    [ -r "$r/date" ] && [ -r "$r/time" ] || continue
    RD=$(cat "$r/date" 2>/dev/null)
    RT=$(cat "$r/time" 2>/dev/null)
    [ -n "$RD" ] && [ -n "$RT" ] || continue
    if [ "$RTC_MODE" = LOCAL ]; then
      RE=$(date -d "$RD $RT" +%s 2>/dev/null) || continue
    else
      RE=$(date -u -d "$RD $RT" +%s 2>/dev/null) || continue
    fi
    NOW=$(date +%s)
    D=$((RE - NOW))
    [ "$D" -lt 0 ] && D=$((-D))
    [ "$D" -le 5 ] && return 0
    RTCLOG="$RTCLOG
$r reads $RD $RT ($RTC_MODE); ${D}s away from system time"
  done
  return 1
}

rtc_try() {
  O=$("$HW" "$@" 2>&1)
  RC=$?
  if [ "$RC" -eq 0 ]; then return 0; fi
  RTCLOG="$RTCLOG
$HW $*: $O"
  if rtc_readback_ok; then
    RTCLOG="$RTCLOG
RTC read-back agrees with the corrected system time"
    return 0
  fi
  return 1
}

rtc_write() {
  rtc_detect
  for c in /usr/sbin/hwclock /sbin/hwclock /usr/bin/hwclock /bin/hwclock; do
    if [ -x "$c" ]; then HW="$c"; break; fi
  done
  if [ -z "$HW" ]; then
    if command -v hwclock >/dev/null 2>&1; then
      HW=$(command -v hwclock)
    fi
  fi
  if [ -z "$HW" ]; then
    if command -v dpkg-query >/dev/null 2>&1 &&
       dpkg-query -W -f='${Status}' util-linux-extra 2>/dev/null | grep -q 'install ok installed'; then
      RTCLOG="$RTCLOG
The hwclock executable could not be located, but util-linux-extra is installed. This is not an RTC hardware failure."
    else
      RTCLOG="$RTCLOG
The hwclock executable could not be located. Check whether util-linux-extra is installed. This does not mean the RTC chip is missing."
    fi
    return 1
  fi

  # First use the machine's existing /etc/adjtime mode.
  rtc_try --systohc && return 0
  for d in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$d" ] || continue
    rtc_try --systohc --rtc "$d" && return 0
  done

  # Bypass a broken/missing adjtime file, but KEEP its LOCAL/UTC mode.
  rtc_try --systohc --noadjfile "--$( [ "$RTC_MODE" = LOCAL ] && echo localtime || echo utc )" && return 0
  for d in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$d" ] || continue
    rtc_try --systohc --noadjfile "--$( [ "$RTC_MODE" = LOCAL ] && echo localtime || echo utc )" --rtc "$d" && return 0
  done

  # Never use direct ISA writes on modern tablets as a blind fallback.
  RTCLOG="$RTCLOG
Linux could not WRITE the RTC. The hardware may still be present and readable.
$($HW --show --verbose 2>&1 | head -n 16)"
  return 1
}

fake_clock_save() {
  if command -v fake-hwclock >/dev/null 2>&1; then
    O=$(fake-hwclock save 2>&1)
    if [ $? -eq 0 ]; then
      FAKELOG="Saved an approximate boot timestamp to disk (not a real RTC)."
      return 0
    fi
    FAKELOG="fake-hwclock save failed: $O"
    return 1
  fi
  FAKELOG="No RTC is exposed to Linux and fake-hwclock is not installed."
  return 1
}

rtc_store() {
  RTC=ok
  if ! rtc_write; then
    if [ "$RTC_PRESENT" -eq 1 ]; then
      RTC=unwritable
    else
      RTC=unavailable
      fake_clock_save && RTC=fake
    fi
  fi
}
        if ! O=$(date -u -s "@$2" 2>&1); then
            if [ "$1" = set ]; then echo OSMSET_FAIL; else echo OSMSYNC_FAIL; fi
            echo "date -u -s: $O"
            exit 1
        fi
        rtc_store
        if [ "$1" = set ]; then
            echo "OSMSET_OK:$RTC"
        else
            echo "OSMSYNC_OK:$RTC:network NTP server"
        fi
        echo "$RTCLOG"
        echo "$FAKELOG"
        exit 0
        ;;
    chrony)
        [ "$#" -eq 1 ] || exit 2
        echo CHRONY_REACHED
        chronyc -a online 2>&1
        chronyc -a 'burst 4/4' 2>&1
        chronyc -n waitsync 10 1 100 2 2>&1
        RES=$?
        chronyc -n tracking 2>&1
        if [ "$RES" -eq 0 ]; then echo CHRONY_SYNC_OK
        else echo CHRONY_SYNC_WAIT; fi
        exit 0
        ;;
    http-sync)
        [ "$#" -eq 1 ] || exit 2
RTCLOG=""
FAKELOG=""
RTC_PRESENT=0
HW=""
RTC_MODE=UTC
[ -f /etc/adjtime ] && [ "$(sed -n '3p' /etc/adjtime 2>/dev/null)" = LOCAL ] && RTC_MODE=LOCAL

rtc_detect() {
  for r in /sys/class/rtc/rtc*; do
    [ -d "$r" ] || continue
    RTC_PRESENT=1
    RTCLOG="$RTCLOG
Detected $r ($(cat "$r/name" 2>/dev/null))"
  done
  for r in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$r" ] && RTC_PRESENT=1
  done
  [ -r /proc/driver/rtc ] && RTC_PRESENT=1
  RTCLOG="$RTCLOG
RTC time scale from /etc/adjtime: $RTC_MODE"
}

rtc_readback_ok() {
  for r in /sys/class/rtc/rtc*; do
    [ -r "$r/date" ] && [ -r "$r/time" ] || continue
    RD=$(cat "$r/date" 2>/dev/null)
    RT=$(cat "$r/time" 2>/dev/null)
    [ -n "$RD" ] && [ -n "$RT" ] || continue
    if [ "$RTC_MODE" = LOCAL ]; then
      RE=$(date -d "$RD $RT" +%s 2>/dev/null) || continue
    else
      RE=$(date -u -d "$RD $RT" +%s 2>/dev/null) || continue
    fi
    NOW=$(date +%s)
    D=$((RE - NOW))
    [ "$D" -lt 0 ] && D=$((-D))
    [ "$D" -le 5 ] && return 0
    RTCLOG="$RTCLOG
$r reads $RD $RT ($RTC_MODE); ${D}s away from system time"
  done
  return 1
}

rtc_try() {
  O=$("$HW" "$@" 2>&1)
  RC=$?
  if [ "$RC" -eq 0 ]; then return 0; fi
  RTCLOG="$RTCLOG
$HW $*: $O"
  if rtc_readback_ok; then
    RTCLOG="$RTCLOG
RTC read-back agrees with the corrected system time"
    return 0
  fi
  return 1
}

rtc_write() {
  rtc_detect
  for c in /usr/sbin/hwclock /sbin/hwclock /usr/bin/hwclock /bin/hwclock; do
    if [ -x "$c" ]; then HW="$c"; break; fi
  done
  if [ -z "$HW" ]; then
    if command -v hwclock >/dev/null 2>&1; then
      HW=$(command -v hwclock)
    fi
  fi
  if [ -z "$HW" ]; then
    if command -v dpkg-query >/dev/null 2>&1 &&
       dpkg-query -W -f='${Status}' util-linux-extra 2>/dev/null | grep -q 'install ok installed'; then
      RTCLOG="$RTCLOG
The hwclock executable could not be located, but util-linux-extra is installed. This is not an RTC hardware failure."
    else
      RTCLOG="$RTCLOG
The hwclock executable could not be located. Check whether util-linux-extra is installed. This does not mean the RTC chip is missing."
    fi
    return 1
  fi

  # First use the machine's existing /etc/adjtime mode.
  rtc_try --systohc && return 0
  for d in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$d" ] || continue
    rtc_try --systohc --rtc "$d" && return 0
  done

  # Bypass a broken/missing adjtime file, but KEEP its LOCAL/UTC mode.
  rtc_try --systohc --noadjfile "--$( [ "$RTC_MODE" = LOCAL ] && echo localtime || echo utc )" && return 0
  for d in /dev/rtc /dev/rtc[0-9]* /dev/misc/rtc; do
    [ -e "$d" ] || continue
    rtc_try --systohc --noadjfile "--$( [ "$RTC_MODE" = LOCAL ] && echo localtime || echo utc )" --rtc "$d" && return 0
  done

  # Never use direct ISA writes on modern tablets as a blind fallback.
  RTCLOG="$RTCLOG
Linux could not WRITE the RTC. The hardware may still be present and readable.
$($HW --show --verbose 2>&1 | head -n 16)"
  return 1
}

fake_clock_save() {
  if command -v fake-hwclock >/dev/null 2>&1; then
    O=$(fake-hwclock save 2>&1)
    if [ $? -eq 0 ]; then
      FAKELOG="Saved an approximate boot timestamp to disk (not a real RTC)."
      return 0
    fi
    FAKELOG="fake-hwclock save failed: $O"
    return 1
  fi
  FAKELOG="No RTC is exposed to Linux and fake-hwclock is not installed."
  return 1
}

rtc_store() {
  RTC=ok
  if ! rtc_write; then
    if [ "$RTC_PRESENT" -eq 1 ]; then
      RTC=unwritable
    else
      RTC=unavailable
      fake_clock_save && RTC=fake
    fi
  fi
}
LOG=""
SRC=""
HAVE_CURL=0; command -v curl >/dev/null 2>&1 && HAVE_CURL=1
HAVE_WGET=0; command -v wget >/dev/null 2>&1 && HAVE_WGET=1
if [ "$HAVE_CURL" = 0 ] && [ "$HAVE_WGET" = 0 ]; then
  LOG="$LOG
neither curl nor wget is installed, so there is no way to fetch the time"
fi
for url in http://deb.devuan.org/ https://deb.devuan.org/ http://www.google.com/; do
  D=""
  if [ "$HAVE_CURL" = 1 ]; then
    D=$(curl -sI -m 8 "$url" 2>/dev/null | grep -i '^date:' | head -n1 | sed 's/^[Dd][Aa][Tt][Ee]:[ ]*//' | tr -d '\r')
  fi
  if [ -z "$D" ] && [ "$HAVE_WGET" = 1 ]; then
    D=$(wget -S --spider -T 8 -q -O /dev/null "$url" 2>&1 | grep -i '^ *date:' | head -n1 | sed 's/^ *[Dd][Aa][Tt][Ee]:[ ]*//' | tr -d '\r')
  fi
  if [ -n "$D" ]; then
    if date -u -s "$D" >/dev/null 2>&1; then SRC="the web server at $url"; break; fi
    LOG="$LOG
could not apply the date from $url: $D"
  else
    LOG="$LOG
no date sent by $url"
  fi
done
if [ -z "$SRC" ]; then
  echo OSMSYNC_FAIL
  echo "$LOG"
  exit 1
fi
rtc_store
echo "OSMSYNC_OK:$RTC:$SRC"
echo "$LOG"
echo "$RTCLOG"
echo "$FAKELOG"
exit 0
        ;;
    *)
        echo "Unsupported time operation"
        exit 2
        ;;
esac
ALT_TIME_HELPER_CONTENT
sudo chown root:root /usr/local/sbin/alternix-time-helper
sudo chmod 0755 /usr/local/sbin/alternix-time-helper
# No NOPASSWD clock exception: all administrative actions now use
# sudo's standard PAM pattern/PIN prompt. Existing exceptions are removed
# at the end of installation by alternix-auth-setup.sh.
if ! sudo test -x /usr/local/sbin/alternix-time-helper; then
    echo "ERROR: Alternix clock helper is missing or not executable." >&2
    exit 1
fi
echo "[Time] Clock helper installed (PAM authentication applies)."

echo ""
echo "[System] Installing Qtile, Qtile-Extras & mypy"
pip3 install qtile qtile-extras mypy --break-system-packages

echo "NOTE: snapd is NOT available on Devuan (it depends on systemd)."
echo "If snap packages are needed, use flatpak equivalents instead."
echo ""
echo ""



# ────────────────────────────────────────────────
#  Install Flatpaks
# ────────────────────────────────────────────────

echo "[System] Clearing space in /var/cache/apt/archive..."
sudo rm -rf /var/cache/apt/archives

echo "[System] Adding flatpak Components.."
sudo flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

echo "[System] Installing Flatpaks..."
flatpak install -y flathub com.github.joseexposito.touche
flatpak install -y flathub org.kde.kweather
flatpak install -y flathub org.kde.qrca
flatpak install -y flathub com.freerdp.FreeRDP
flatpak install -y flathub com.github.tchx84.Flatseal
flatpak install -y flathub io.github.leolost2605.emergency-alerts

# Optional Flatpaks are deliberately excluded from the ISO prebuilt preview.
# Only ask during an interactive installation, never in live-build's chroot.
# A non-interactive ISO installer can pass ALTERNIX_INSTALL_GAMES=yes/no and
# ALTERNIX_INSTALL_EXTRAS=yes/no after gathering the user's choices itself.
alt_wants_optional_flatpaks() {
    local category="$1" preset="$2" choice=""

    if [ "$ALT_IS_LIVE_BUILD" = 1 ]; then
        echo "[Flatpak] ISO prebuild: not including optional $category."
        return 1
    fi

    case "${preset,,}" in
        y|yes|1|true|on)  echo "[Flatpak] $category selected."; return 0 ;;
        n|no|0|false|off) echo "[Flatpak] $category skipped."; return 1 ;;
        '') ;;
        *) echo "WARNING: Unrecognized $category selection '$preset'; skipping." >&2; return 1 ;;
    esac

    # The ISO graphical/TUI installer supplies a pipe as stdin and collects
    # optional components on its own page. Never prompt on /dev/tty here:
    # that would be an invisible, blocking second question during install.
    # Direct desktop installs from an interactive terminal still ask.
    if [ ! -t 0 ]; then
        echo "[Flatpak] $category selection deferred to the ISO installer (non-interactive desktop setup)."
        return 1
    fi

    # Don't stall an unattended install waiting for input. The two choices
    # default to No if no interactive terminal is present.
    if ! ( : </dev/tty ) 2>/dev/null; then
        echo "[Flatpak] No interactive terminal for $category; skipping (default: No)."
        return 1
    fi

    while true; do
        if ! IFS= read -r -p "Install $category? [y/N]: " choice </dev/tty; then
            echo "[Flatpak] No selection received; skipping $category."
            return 1
        fi
        case "${choice,,}" in
            y|yes) echo "[Flatpak] $category selected."; return 0 ;;
            ''|n|no) echo "[Flatpak] $category skipped."; return 1 ;;
            *) echo "Please enter Y or N." ;;
        esac
    done
}

echo ""
echo "=============================================================="
echo "       AlternixOS - Optional Flatpak Applications"
echo "=============================================================="
echo "Games:  RetroDECK, Warzone 2100, 0 A.D."
echo "Extras: Nucleus, Gaia Sky, Emergency Alerts, Keypunch, Shortwave"
echo "Choose each group separately (press Enter to skip)."
echo ""

# Flatpak Games:
if alt_wants_optional_flatpaks "Games" "${ALTERNIX_INSTALL_GAMES:-}"; then
    flatpak install -y flathub net.retrodeck.retrodeck
    flatpak install -y flathub net.wz2100.wz2100
    flatpak install -y flathub com.play0ad.zeroad
fi

# Flatpak extras:
if alt_wants_optional_flatpaks "Extras" "${ALTERNIX_INSTALL_EXTRAS:-}"; then
    flatpak install -y flathub page.codeberg.lo_vely.Nucleus
    flatpak install -y flathub space.gaiasky.GaiaSky
    flatpak install -y flathub no.bragefuglseth.Keypunch
    flatpak install -y flathub de.haeckerfelix.Shortwave
fi

echo "[System] Installing Bauh Application Manager.."
sudo pip3 install bauh --break-system-packages


# ────────────────────────────────────────────────
# Install all .deb packages in ~/Alternix/installers/
# ────────────────────────────────────────────────
echo " "
echo "[System] Installing local .deb packages..."

INSTALLER_DIR="$ALT_ROOT/Alternix/installers"

if [ -d "$INSTALLER_DIR" ]; then
    DEB_COUNT=$(ls -1 "$INSTALLER_DIR"/*.deb 2>/dev/null | wc -l)

    if [ "$DEB_COUNT" -gt 0 ]; then
        echo "• Found $DEB_COUNT installer package(s). Installing..."
        sudo dpkg -i "$INSTALLER_DIR"/*.deb || true
        sudo apt -f install -y
        sudo dpkg -i "$INSTALLER_DIR"/*.deb || true
        echo "• Local installer packages installed."
    else
        echo "• No .deb files in installers folder, skipping."
    fi
else
    echo "• No installers folder found, skipping."
fi



# ────────────────────────────────────────────────
#            Curl Commands
# ────────────────────────────────────────────────

cd "$ALT_ROOT/Alternix"

echo "[System] Installing Starship prompt..."
curl -sS https://starship.rs/install.sh | sh -s -- --yes

if ! grep -Fxq 'eval "$(starship init bash)"' "$TARGET_HOME/.bashrc"; then
    echo 'eval "$(starship init bash)"' >> "$TARGET_HOME/.bashrc"
fi

echo "[System] Installing Brave Browser..."
curl -fsS https://dl.brave.com/install.sh | sh -s -- --yes

#echo "[System] Updating bash aliases..."
#echo 'alias sudo="osm-sudo sudo -S"' >> "$TARGET_HOME/.bashrc"

# ────────────────────────────────────────────────
# Copy ALL configs from ~/Alternix/configs → ~/.config
# ────────────────────────────────────────────────
echo " "
echo "[Config] Installing user configs..."

CONFIG_SRC="$ALT_ROOT/Alternix/configs"
CONFIG_DST="$TARGET_HOME/.config"

sudo cp "$ALT_ROOT/Alternix/configs/.alacritty.toml" "$TARGET_HOME/.alacritty.toml"

mkdir -p "$CONFIG_DST"

if [ -d "$CONFIG_SRC" ]; then
    echo "• Copying configs from $CONFIG_SRC → $CONFIG_DST"
    cp -r "$CONFIG_SRC/"* "$CONFIG_DST/"
    echo "• Configs installed."
else
    echo "• No configs folder found, skipping."
fi

sudo cp -r "$ALT_ROOT/Alternix/onboard" /usr/share/onboard



# ────────────────────────────────────────────────
# Install Fonts
# ────────────────────────────────────────────────
echo " "
echo "[Config] Installing Fonts..."

if [ -d "$ALT_ROOT/Alternix/fonts" ]; then
    sudo mkdir -p /usr/local/share/fonts/alternix
    sudo cp -r "$ALT_ROOT/Alternix/fonts/"* /usr/local/share/fonts/alternix/
    sudo fc-cache -f
    echo "• Fonts installed successfully."
else
    echo "• No fonts folder found, skipping."
fi

ALT_VLC_USER="$TARGET_USER"
ALT_VLC_HOME="$TARGET_HOME"
# ────────────────────────────────────────────────
# Alternix VLC — compiled Qt5 theme + responsive player layout INSIDE VLC.
# VLC itself is still the standard Qt QMainWindow; Qtile owns tile geometry.
# Build this shipped, complete source directly here (no patch files/scripts).
# ────────────────────────────────────────────────
echo "[VLC] Building and activating Alternix native Qt player theme..."
sudo apt-get install -y qtbase5-dev qtbase5-dev-tools vlc vlc-plugin-qt qt5-style-kvantum

sudo install -d -m 0755 /usr/share/Kvantum/AlternixVLC
sudo install -m 0644 "$ALT_VLC_THEME_SRC/Kvantum/AlternixVLC/AlternixVLC.svg" \
    /usr/share/Kvantum/AlternixVLC/AlternixVLC.svg
sudo install -m 0644 "$ALT_VLC_THEME_SRC/Kvantum/AlternixVLC/AlternixVLC.kvconfig" \
    /usr/share/Kvantum/AlternixVLC/AlternixVLC.kvconfig

sudo install -d -m 0755 /usr/share/alternix/vlc/icons /usr/share/alternix/vlc/qt5-style
for vlc_icon in "$ALT_VLC_THEME_SRC"/icons/*.png; do
    [ -f "$vlc_icon" ] || { echo "ERROR: Alternix VLC icon set is missing." >&2; exit 1; }
    sudo install -m 0644 "$vlc_icon" /usr/share/alternix/vlc/icons/
done
for vlc_style_source in alternixvlcstyle.cpp alternixvlcstyle.json; do
    sudo install -m 0644 "$ALT_VLC_THEME_SRC/qt5-style/$vlc_style_source" \
        "/usr/share/alternix/vlc/qt5-style/$vlc_style_source"
done

ALT_VLC_MOC="$(command -v moc || true)"
[ -n "$ALT_VLC_MOC" ] || ALT_VLC_MOC=/usr/lib/qt5/bin/moc
if [ ! -x "$ALT_VLC_MOC" ] || ! command -v qmake >/dev/null 2>&1 || \
   ! pkg-config --exists Qt5Widgets Qt5Gui Qt5Core; then
    echo "ERROR: VLC Qt5 theme build tools are unavailable." >&2
    exit 1
fi
ALT_VLC_QT_VERSION="$(qmake -query QT_VERSION 2>/dev/null)"
case "$ALT_VLC_QT_VERSION" in
    5.*) ;;
    *) echo "ERROR: Expected Qt5 qmake, found Qt version: $ALT_VLC_QT_VERSION" >&2; exit 1 ;;
esac
ALT_VLC_PLUGIN_ROOT="$(qmake -query QT_INSTALL_PLUGINS 2>/dev/null)"
if [ -z "$ALT_VLC_PLUGIN_ROOT" ] || [ "$ALT_VLC_PLUGIN_ROOT" = / ]; then
    echo "ERROR: Cannot determine the Qt5 style plugin directory." >&2
    exit 1
fi
ALT_VLC_BUILD_DIR="$(mktemp -d /tmp/alternix-vlc-native.XXXXXXXX)"
if ! "$ALT_VLC_MOC" "$ALT_VLC_THEME_SRC/qt5-style/alternixvlcstyle.cpp" \
        -o "$ALT_VLC_BUILD_DIR/alternixvlcstyle.moc" || \
   ! g++ -std=c++17 -O2 -fPIC -shared \
        -I "$ALT_VLC_BUILD_DIR" \
        "$ALT_VLC_THEME_SRC/qt5-style/alternixvlcstyle.cpp" \
        -o "$ALT_VLC_BUILD_DIR/libalternixvlcstyle.so" \
        $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core); then
    echo "ERROR: Alternix native VLC Qt theme failed to compile. The previous plugin remains untouched." >&2
    rm -rf -- "$ALT_VLC_BUILD_DIR"
    exit 1
fi
sudo install -D -m 0644 "$ALT_VLC_BUILD_DIR/libalternixvlcstyle.so" \
    "$ALT_VLC_PLUGIN_ROOT/styles/libalternixvlcstyle.so"
rm -rf -- "$ALT_VLC_BUILD_DIR"
if [ ! -s "$ALT_VLC_PLUGIN_ROOT/styles/libalternixvlcstyle.so" ]; then
    echo "ERROR: Native Qt theme plugin installation failed." >&2
    exit 1
fi

# The preceding integration installed this exact fixed-size legacy skin.
# It must not remain enabled as a seemingly valid Alternix player option.
# Remove only our own named skin file; leave other user skins untouched.
sudo rm -f -- "$ALT_VLC_HOME/.local/share/vlc/skins2/Alternix-VLC.vlt" \
              "/etc/skel/.local/share/vlc/skins2/Alternix-VLC.vlt"

# Configure the logged-in desktop account and defaults for future users.
# Do not change the globally selected Kvantum theme or create new launchers.
sudo python3 - "$ALT_VLC_HOME" "$ALT_VLC_USER" /etc/skel <<'ALT_VLC_CONFIGURATION'
import os
import pwd
import re
import sys
from pathlib import Path

home = Path(sys.argv[1])
account = pwd.getpwnam(sys.argv[2])


def save(path, contents, owner):
    missing = []
    parent = path.parent
    while not parent.exists():
        missing.append(parent)
        parent = parent.parent
    path.parent.mkdir(parents=True, exist_ok=True)
    for directory in reversed(missing):
        if owner is not None:
            os.chown(directory, *owner)
    if not path.is_file() or path.read_text(encoding='utf-8') != contents:
        path.write_text(contents, encoding='utf-8')
    if owner is not None:
        os.chown(path, *owner)
    os.chmod(path, 0o644)


def modify_ini(path, section_name, changes, owner):
    """Preserve every unrelated preference and replace only requested keys."""
    lines = path.read_text(encoding='utf-8').splitlines(keepends=True) if path.is_file() else []
    output = []
    active = None
    found = False
    written = set()

    def finish():
        for key, value in changes.items():
            if key not in written:
                output.append(f'{key}={value}\n')
                written.add(key)

    for line in lines:
        section = re.match(r'^\s*\[([^]]+)\]', line)
        if section:
            if active == section_name:
                finish()
            active = section.group(1).strip()
            found |= active == section_name
            output.append(line)
            continue
        if active == section_name:
            key_match = re.match(r'^\s*#?\s*([\w.-]+)\s*=', line)
            if key_match and key_match.group(1) in changes:
                key = key_match.group(1)
                if key not in written:
                    output.append(f'{key}={changes[key]}\n')
                    written.add(key)
                continue
        output.append(line)
    if active == section_name:
        finish()
    if not found:
        if output and not output[-1].endswith('\n'):
            output[-1] += '\n'
        output.append(f'\n[{section_name}]\n')
        finish()
    save(path, ''.join(output), owner)


def map_application_kvantum(path, owner):
    """Assign just vlc to AlternixVLC; preserve all other app assignments."""
    lines = path.read_text(encoding='utf-8').splitlines(keepends=True) if path.is_file() else []
    result = []
    section = None
    seen_section = False
    wrote = False
    for line in lines:
        heading = re.match(r'^\s*\[([^]]+)\]', line)
        if heading:
            if section == 'Applications' and not wrote:
                result.append('AlternixVLC=vlc\n')
                wrote = True
            section = heading.group(1).strip()
            seen_section |= section == 'Applications'
            result.append(line)
            continue
        assignment = re.match(r'^(\s*)([A-Za-z0-9_.-]+)(\s*=\s*)([^\r\n]*)(\r?\n?)$', line)
        if section == 'Applications' and assignment:
            lead, theme, sep, apps, ending = assignment.groups()
            items = [app.strip() for app in apps.split(',') if app.strip() and app.strip() != 'vlc']
            if theme == 'AlternixVLC' and not wrote:
                items.append('vlc')
                wrote = True
            if items:
                result.append(lead + theme + sep + ', '.join(items) + (ending or '\n'))
            continue
        result.append(line)
    if section == 'Applications' and not wrote:
        result.append('AlternixVLC=vlc\n')
    elif not seen_section:
        if result and not result[-1].endswith('\n'):
            result[-1] += '\n'
        result.extend(['\n[Applications]\n', 'AlternixVLC=vlc\n'])
    save(path, ''.join(result), owner)


def remove_prior_duplicate_launcher(path):
    """Remove only the redundant user launcher generated by v1 integration."""
    if not path.is_file() or path.is_symlink():
        return
    content = path.read_text(encoding='utf-8')
    if ('QT_STYLE_OVERRIDE=kvantum' in content and
            '--intf=qt' in content and
            '--no-qt-video-autoresize' in content and
            re.search(r'(?m)^\s*\[Desktop Entry\]\s*$', content)):
        path.unlink()
        print('[VLC] Removed previous generated duplicate launcher:', path)
    else:
        print('[VLC] Kept independently customized user launcher:', path)


for target, owner in ((home, (account.pw_uid, account.pw_gid)), (Path(sys.argv[3]), None)):
    map_application_kvantum(target / '.config/Kvantum/kvantum.kvconfig', owner)
    modify_ini(target / '.config/vlc/vlcrc', 'core', {'intf': 'qt'}, owner)
    modify_ini(target / '.config/vlc/vlcrc', 'qt', {
        'qt-video-autoresize': '0',
        'qt-dark-palette': '0',
        'embedded-video': '1',
        'qt-minimal-view': '0',
    }, owner)
    modify_ini(target / '.config/vlc/vlc-qt-interface.conf', 'MainWindow', {
        'QtStyle': 'AlternixVLC',
        'MainToolbar1': '65;2;10;9;19;20;7;36;65',
        'MainToolbar2': '65;1;22;0;23;12;65',
        'ToolbarPos': 'false',
    }, owner)
    remove_prior_duplicate_launcher(target / '.local/share/applications/vlc.desktop')


# Modify the *existing* distribution desktop entry IN PLACE, so no extra VLC
# appears in osm-launcher. --intf=qt wins over a saved Skins2 preference;
# this is especially important when VLC previously ran a .vlt skin. Preserve
# the distro desktop name, menu categories, MIME types and %U arguments.
launcher = Path('/usr/share/applications/vlc.desktop')
if launcher.is_file() and not launcher.is_symlink():
    raw = launcher.read_text(encoding='utf-8')
    output = []
    changed_exec = 0
    for line in raw.splitlines(keepends=True):
        if not line.startswith('Exec='):
            output.append(line)
            continue
        command = line[len('Exec='):].rstrip('\r\n')
        # Only change commands which start the system VLC binary.
        match = re.search(r'(?<!\S)(?:/[^\s]*)?\bvlc(?=\s|$)', command)
        if match is None:
            output.append(line)
            continue
        command = re.sub(r'(?<!\S)--intf(?:=|\s+)skins2(?=\s|$)', '', command)
        command = re.sub(r'(?<!\S)--skins2-last(?:=\S+|\s+\S+)', '', command)
        command = re.sub(r'(?<!\S)QT_STYLE_OVERRIDE=\S+\s*', '', command).strip()
        match = re.search(r'(?<!\S)(?:/[^\s]*)?\bvlc(?=\s|$)', command)
        # The natural user-native interface is enforced for THIS launcher,
        # not the global /usr/bin/vlc binary or unrelated applications.
        if not re.search(r'(?<!\S)--intf(?:=|\s+)qt(?=\s|$)', command):
            command = command[:match.end()] + ' --intf=qt' + command[match.end():]
        if '--no-qt-video-autoresize' not in command:
            command = command.replace('--intf=qt', '--intf=qt --no-qt-video-autoresize', 1)
        # No extra desktop entry: this style override is specific to VLC only.
        if command.startswith('env '):
            command = 'env QT_STYLE_OVERRIDE=AlternixVLC ' + command[4:]
        else:
            command = 'env QT_STYLE_OVERRIDE=AlternixVLC ' + command
        output.append('Exec=' + command + '\n')
        changed_exec += 1
    if changed_exec:
        updated = ''.join(output)
        if updated != raw:
            backup = Path('/usr/share/alternix/vlc/vlc.desktop.original')
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                backup.write_text(raw, encoding='utf-8')
                backup.chmod(0o644)
            launcher.write_text(updated, encoding='utf-8')
            launcher.chmod(0o644)
        print(f'[VLC] Updated {changed_exec} existing desktop Exec line(s) for native Qt.')
    else:
        print('[VLC] WARNING: /usr/share/applications/vlc.desktop has no recognized VLC command.')
else:
    print('[VLC] WARNING: distro VLC launcher not present: /usr/share/applications/vlc.desktop')

print('[VLC] Alternix Qt player layout and theme selected; standard VLC window remains under Qtile.')
ALT_VLC_CONFIGURATION
if command -v update-desktop-database >/dev/null 2>&1; then
    sudo update-desktop-database /usr/share/applications 2>/dev/null || true
    sudo update-desktop-database "$ALT_VLC_HOME/.local/share/applications" 2>/dev/null || true
fi
if [ ! -s /usr/share/Kvantum/AlternixVLC/AlternixVLC.svg ] || \
   [ ! -s "$ALT_VLC_HOME/.config/vlc/vlc-qt-interface.conf" ]; then
    echo "ERROR: AlternixVLC native Qt theme installation failed verification." >&2
    exit 1
fi
# Do not force-close VLC during an installation or updater (unsaved playback
# state could be lost). Close all running VLC instances after the update.
if pgrep -u "$ALT_VLC_USER" -x vlc >/dev/null 2>&1; then
    echo "[VLC] NOTE: VLC is running. Exit all VLC windows/tray instances before reopening it."
fi
echo "[VLC] Compiled Alternix Qt theme installed; VLC uses a single tiled native window."

# ────────────────────────────────────────────────
# Install Wallpapers
# ────────────────────────────────────────────────
echo " "
echo "[Config] Installing Wallpapers..."

WALL_DST="$TARGET_HOME/Pictures/wallpapers"
mkdir -p "$WALL_DST"

if [ -d "$ALT_ROOT/Alternix/wallpapers" ]; then
    cp -r "$ALT_ROOT/Alternix/wallpapers/"* "$WALL_DST/"
    echo "• Wallpapers installed to $WALL_DST"
else
    echo "---------------------------------------"
    echo "• No wallpapers folder found, skipping."
    echo "---------------------------------------"
fi


# ────────────────────────────────────────────────
# Install Extras
# ────────────────────────────────────────────────
echo " "
echo "[Config] Installing Extras..."
mkdir -p "$TARGET_HOME/extras"

if [ -d "$ALT_ROOT/Alternix/extras" ]; then
    sudo cp -r "$ALT_ROOT/Alternix/extras/"* "$TARGET_HOME/extras/"

    echo "• Extras installed successfully."
else
    echo "--------------------------------"
    echo "• [ERROR] Installing Extras..."
    echo "--------------------------------"
fi


# ────────────────────────────────────────────────
# 2. Create & activate Qtile venv
# ────────────────────────────────────────────────
echo " "
echo "[2/10] Creating virtual environment (qtile_venv)..."

if [ ! -d "$TARGET_HOME/.qtile_venv" ]; then
    python3 -m venv "$TARGET_HOME/.qtile_venv"
fi

source "$TARGET_HOME/.qtile_venv/bin/activate"

echo "[3/10] Installing Python pip dependencies..."
# dbus-fast is what lets qtile hear elogind's sleep/resume signals.
# Without it @hook.subscribe.resume in config.py never fires, so the
# screen would not lock after waking from a lid-close suspend.
pip3 install qtile qtile-extras mypy dbus-fast --break-system-packages

# Symlink qtile binary to where udev rules expect it
sudo mkdir -p /usr/lib/udev
sudo ln -sf "$TARGET_HOME/.qtile_venv/bin/qtile" /usr/lib/udev/qtile

# Reloading udev rules only works against a running udevd — this script
# may run inside a chroot (e.g. the installer) where there's no
# udevd to talk to. udevadm exits non-zero in that case and would take
# down the rest of the install under `set -e`. Not fatal either way.
sudo udevadm control --reload-rules 2>/dev/null || true


# ────────────────────────────────────────────────
# 2a. Scripts
# ────────────────────────────────────────────────
echo " "
echo "[2a/10] Installing Scrolling Layout for Qtile..."

mkdir -p "$TARGET_HOME/.config/Alternix"
mkdir -p "$TARGET_HOME/.local/bin"
cp -r "$ALT_ROOT/Alternix/scripts" "$TARGET_HOME/.config/Alternix/"

# Refresh the exact four backends required by the current Display module.
# The normal scripts copy above also retains all unrelated Alternix scripts.
for alt_input_file in \
    alternix-rotate-monitor.sh \
    alternix-rotate-setup.sh \
    alternix-rotate-toggle.sh \
    alternix-stylus-apply.sh; do
    sudo install -m 0755 "$ALT_INPUT_SOURCE_DIR/$alt_input_file" \
        "$TARGET_HOME/.config/Alternix/scripts/$alt_input_file"
done
# The ISO may create the final desktop user after the preview user. Make
# these same runtime sources available through standard home provisioning.
sudo install -d -m 0755 /etc/skel/.config/Alternix/scripts
for alt_input_file in \
    alternix-rotate-monitor.sh \
    alternix-rotate-setup.sh \
    alternix-rotate-toggle.sh \
    alternix-stylus-apply.sh; do
    sudo install -m 0755 "$ALT_INPUT_SOURCE_DIR/$alt_input_file" \
        "/etc/skel/.config/Alternix/scripts/$alt_input_file"
done
cd "$TARGET_HOME/.config/Alternix/scripts"
chmod +x alternix-audio-fix.sh

# ────────────────────────────────────────────────
# One-time AlternixOS audio provisioning (Devuan / SysVinit)
# - ISO prebuild: stage broad firmware, do NOT scan builder hardware.
# - Disk installer: use --install-target with the ACTUAL target root.
# - Existing installed machine: scan hardware once, with a completion marker.
# - Live preview: never mark the live overlay as the installed system.
# No recurring audio repair or desktop login autostart is installed.
# ────────────────────────────────────────────────
echo "[Audio] Preparing hardware-aware audio support..."
ALT_AUDIO_SETUP_FAILED=0
if [ -n "${ALTERNIX_AUDIO_TARGET_ROOT:-}" ]; then
    echo "[Audio] Configuring the new OS at $ALTERNIX_AUDIO_TARGET_ROOT using this machine's hardware..."
    if ! sudo bash "$ALT_AUDIO_SOURCE" --install-target "$ALTERNIX_AUDIO_TARGET_ROOT"; then
        echo "WARNING: Target-system audio setup failed or is incomplete. Check the audio report in the target's /var/log/alternix/." >&2
        ALT_AUDIO_SETUP_FAILED=1
    fi
elif [ "$ALT_IS_LIVE_BUILD" = 1 ]; then
    echo "[Audio] Building ISO: provisioning broad audio/firmware support without scanning host hardware..."
    if ! sudo bash "$ALT_AUDIO_SOURCE" --image-prep; then
        echo "WARNING: ISO audio image preparation failed. Check /var/log/alternix/." >&2
        ALT_AUDIO_SETUP_FAILED=1
    fi
elif [ -e /run/live/medium ] || [ -e /lib/live/mount/medium ] || \
     grep -Eq '(^|[[:space:]])boot=live([[:space:]]|$)' /proc/cmdline 2>/dev/null; then
    echo "[Audio] Live desktop detected: not configuring or stamping the temporary live root."
    echo "[Audio] The disk installer must call --install-target with its mounted target root."
else
    echo "[Audio] Configuring audio on this installed OS (once per installation)..."
    if ! sudo bash "$ALT_AUDIO_SOURCE" --install; then
        echo "WARNING: Audio provisioning is incomplete. The updater can retry it; see /var/log/alternix/." >&2
        ALT_AUDIO_SETUP_FAILED=1
    fi
fi

echo "• [Configuring AlternixOS touchscroll]..."
sudo install -d -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0755 "$TARGET_HOME/.local/bin"
sudo install -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0755 \
    "$ALT_INPUT_SOURCE_DIR/alternix-touchscroll.py" \
    "$TARGET_HOME/.local/bin/alternix-touchscroll.py" || exit 1

echo "• [Configuring AlternixOS Android layer]..."
sudo install -m 0755 "$ALT_INPUT_SOURCE_DIR/alternix-waydroid-session" \
    /usr/local/bin/alternix-waydroid-session || exit 1

echo "• [Configuring AlternixOS Windows layer]..."
sudo install -m 0755 "$ALT_INPUT_SOURCE_DIR/alternix-exe" \
    /usr/local/bin/alternix-exe || exit 1


# ────────────────────────────────────────────────
# 3. Configure xinitrc autostart
# ────────────────────────────────────────────────
echo " "
echo "[4/10] Creating .xinitrc autostart..."
cat <<'EOF' > "$TARGET_HOME/.xinitrc"
#!/bin/sh
. "$HOME/.qtile_venv/bin/activate"
# AlternixOS X11 pen/touch + auto-rotation login restoration.
# Qtile does not automatically run ~/.config/autostart/*.desktop entries.
# These settings only run after the user deliberately saves/enables them.
ALT_INPUT_LOGIN_DIR="$HOME/.config/Alternix/scripts"
if [ -s "$HOME/.config/Alternix/stylus.conf" ] && \
   [ -x "$ALT_INPUT_LOGIN_DIR/alternix-stylus-apply.sh" ]; then
    (sleep 1; /bin/bash "$ALT_INPUT_LOGIN_DIR/alternix-stylus-apply.sh" apply) >/dev/null 2>&1 &
fi
if [ -x "$ALT_INPUT_LOGIN_DIR/alternix-rotate-toggle.sh" ]; then
    if [ -f "$HOME/.config/autostart/alternix-auto-rotate.desktop" ]; then
        touch "$HOME/.config/Alternix/rotate-autostart-migrated"
        (sleep 1; /bin/bash "$ALT_INPUT_LOGIN_DIR/alternix-rotate-toggle.sh" on --startup) >/dev/null 2>&1 &
    elif [ ! -e "$HOME/.config/Alternix/rotate-autostart-migrated" ] && \
         grep -Eq '^display_auto_rotate=true[[:space:]]*$' \
            "$HOME/.config/Alternix/osm-settings.conf" 2>/dev/null; then
        # Migrate the old preference once. If later disabled from osm-notify,
        # a stale Settings preference must NOT re-enable it at next login.
        touch "$HOME/.config/Alternix/rotate-autostart-migrated"
        (sleep 1; /bin/bash "$ALT_INPUT_LOGIN_DIR/alternix-rotate-toggle.sh" on) >/dev/null 2>&1 &
    fi
fi
# End AlternixOS input login restoration.
# AlternixOS Welcome first-login guide. The --once mode checks the current
# live/installed boot and leaves a completion marker only at the last page.
# The short delay lets Qtile register as the window manager before fullscreen.
if [ -x /usr/local/bin/welcome ]; then
    /usr/local/bin/welcome --once --startup-delay >/dev/null 2>&1 &
fi
# End AlternixOS Welcome first-login guide.
exec dbus-launch --exit-with-session "$HOME/.qtile_venv/bin/qtile" start
EOF
chmod +x "$TARGET_HOME/.xinitrc"
# The live ISO may create its final user after the preview account. Seed the
# generic Qtile X11 session (but do not overwrite an existing skel launcher).
if [ ! -e /etc/skel/.xinitrc ]; then
    sudo install -m 0755 "$TARGET_HOME/.xinitrc" /etc/skel/.xinitrc
fi


# ────────────────────────────────────────────────
# 4. Bash profile auto startx
# ────────────────────────────────────────────────
echo " "
echo "[6/10] Creating ~/.bash_profile auto-start..."
cat <<EOF > "$TARGET_HOME/.bash_profile"
# auto-start X only on tty1 and only if not already running
if [ -z "\$DISPLAY" ] && [ "\$(tty)" = "/dev/tty1" ]; then
    startx
fi
EOF

# ────────────────────────────────────────────────
# 5. Build Alternix Apps
# ────────────────────────────────────────────────
echo " "
echo "• Creating .local/share/applications folder..."
echo " "
mkdir -p "$TARGET_HOME/.local/share/applications"
echo "[7/10] Building Alternix apps..."
cd "$ALT_ROOT/Alternix" || { echo "ERROR: $ALT_ROOT not found"; exit 1; }

echo "• Building osm-launcher..."
g++ -O3 -fPIC apps/osm-launcher.cpp -o osm-launcher $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m 755 osm-launcher /usr/local/bin/

echo "• Building welcome (responsive fullscreen onboarding)..."
g++ -std=c++17 -O3 -fPIC apps/welcome.cpp -o welcome $(pkg-config --cflags --libs Qt5Widgets) || exit 1
sudo install -m 0755 welcome /usr/local/bin/welcome || exit 1
sudo install -D -m 0644 icons/welcome.png /usr/share/icons/hicolor/256x256/apps/welcome.png || exit 1
# One global launcher: osm-launcher scans /usr/share/applications by default.
sudo tee /usr/share/applications/welcome.desktop >/dev/null <<'ALT_WELCOME_DESKTOP'
[Desktop Entry]
Version=1.0
Type=Application
Name=Welcome
GenericName=AlternixOS Welcome
Comment=Touch-friendly introduction to AlternixOS
Exec=/usr/local/bin/welcome
Icon=welcome
Terminal=false
StartupNotify=false
Categories=Utility;Education;
ALT_WELCOME_DESKTOP
if command -v update-desktop-database >/dev/null 2>&1; then
    sudo update-desktop-database /usr/share/applications 2>/dev/null || true
fi

echo "• Building osm-launcher-lock-cleaner..."
chmod +x osm-launcher-lockclean && sudo mv osm-launcher-lockclean /usr/local/bin/
#sudo install -m 755 osm-launcher-lockclean /usr/local/bin/

echo "• Building osm-lock..."
g++ apps/osm-lock.cpp -o osm-lock -fPIC $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m 755 osm-lock /usr/local/bin/

echo "• Building osm-running..."
g++ apps/osm-running.cpp -o osm-running -fPIC -ldl $(pkg-config --cflags --libs Qt5Widgets) -lX11
sudo install -m 755 osm-running /usr/local/bin/

echo "• Building osm-notify..."
g++ -fPIC apps/osm-notify.cpp -o osm-notify $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core Qt5DBus) -lX11 -lXtst
sudo install -m 755 osm-notify /usr/local/bin/

echo "• Building osm-status..."
g++ -fPIC apps/osm-status.cpp -o osm-status -ldl $(pkg-config --cflags --libs Qt5Widgets Qt5DBus) -lX11
sudo install -m 755 osm-status /usr/local/bin/

echo "• Installing sounds..."
# Drop notify.* and alarm.* (wav/ogg/flac/mp3) in ~/.config/Alternix/sounds/
#mkdir -p "$TARGET_HOME/.config/Alternix/sounds"
cp -r "$ALT_ROOT/Alternix/sounds" "$TARGET_HOME/.config/Alternix/"


echo "• Building osm-clock..."
g++ apps/osm-clock.cpp -o osm-clock -fPIC -ldl $(pkg-config --cflags --libs Qt5Widgets) -lX11
sudo install -m 755 osm-clock /usr/local/bin/

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-clock.desktop"
[Desktop Entry]
Type=Application
Name=Clock
Comment=Clock, Alarms, Timer & Stopwatch for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-clock
Icon=osm-clock
Terminal=false
Categories=Utility;Clock;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-clock.desktop"

echo "• Building osm-paper..."
g++ -fPIC apps/osm-paper.cpp -o osm-paper $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-paper /usr/local/bin/

if [ -f "icons/osm-paper.png" ]; then
    sudo cp icons/osm-paper.png /usr/share/icons/hicolor/64x64/apps/osm-paper.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-paper.desktop"
[Desktop Entry]
Type=Application
Name=Wallpapers
Comment=Picture Manager for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-paper
Icon=osm-paper
Terminal=false
Categories=Utility;FileManager;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-paper.desktop"

echo "• Installing osm-paper-restore (rotation-safe full redraw)..."
sudo install -m 755 "$ALT_PAPER_RESTORE_SOURCE" /usr/local/bin/ || exit 1
# The initial Qtile configuration was already copied from Alternix/configs.
# Seed future accounts with the same post-XRandR wallpaper refresh hook.
sudo install -Dm644 "$ALT_PAPER_QTILE_SOURCE" /etc/skel/.config/qtile/config.py || exit 1

echo "• Building osm-styling..."
g++ -fPIC apps/osm-styling.cpp -o osm-styling $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-styling /usr/local/bin/

echo "• Building osm-files..."
g++ -fPIC apps/osm-files.cpp -o osm-files $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-files /usr/local/bin/

if [ -f "icons/osm-files.png" ]; then
    sudo cp icons/osm-files.png /usr/share/icons/hicolor/64x64/apps/osm-files.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-files.desktop"
[Desktop Entry]
Type=Application
Name=Files
Comment=File Manager for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-files
Icon=osm-files
Terminal=false
Categories=Utility;FileManager;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-files.desktop"

echo "• Building osm-viewer..."
g++ -fPIC apps/osm-viewer.cpp -o osm-viewer $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core poppler-qt5) -Wno-deprecated-declarations
sudo install -m 755 osm-viewer /usr/local/bin/

if [ -f "icons/osm-viewer.png" ]; then
    sudo cp icons/osm-viewer.png /usr/share/icons/hicolor/64x64/apps/osm-viewer.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-viewer.desktop"
[Desktop Entry]
Type=Application
Name=File Editor/Viewer
Comment=File Viewer for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-viewer %U
Icon=osm-viewer
Terminal=false
MimeType=application/octet-stream;application/pdf;text/plain;image/*;inode/directory;
Categories=Utility;FileManager;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-viewer.desktop"

echo "• Building osm-draw..."
g++ -fPIC apps/osm-draw.cpp -o osm-draw -std=c++17 $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m 755 osm-draw /usr/local/bin/

if [ -f "icons/osm-draw.png" ]; then
    sudo cp icons/osm-draw.png /usr/share/icons/hicolor/64x64/apps/osm-draw.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-draw.desktop"
[Desktop Entry]
Type=Application
Name=Draw
Comment=Drawing App for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-draw %U
Icon=osm-draw
Terminal=false
Categories=Utility;Drawing;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-draw.desktop"

echo "• Building osm-rocker..."
g++ -fPIC apps/osm-rocker.cpp -o osm-rocker $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-rocker /usr/local/bin/

echo "• Installing osm-sudo..."
sudo install -m 755 apps/osm-sudo /usr/local/bin/

echo "• Building osm-power..."
g++ -fPIC apps/osm-power.cpp -o osm-power $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-power /usr/local/bin/

echo "• Compiling osm-powerd..."
sudo g++ -O2 apps/osm-powerd.cpp -o osm-powerd
sudo install -m 755 osm-powerd /usr/local/bin/
sudo chown root:root /usr/local/bin/osm-powerd
sudo chmod 4755 /usr/local/bin/osm-powerd

echo "• Building osm-lockscreen..."
g++ -fPIC apps/osm-lockscreen.cpp -o osm-lockscreen $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-lockscreen /usr/local/bin/

echo "• Building osm-kernels..."
g++ -fPIC apps/osm-kernels.cpp -o osm-kernels $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m 755 osm-kernels /usr/local/bin/

if [ -f "icons/osm-kernels.png" ]; then
    sudo cp icons/osm-kernels.png /usr/share/icons/hicolor/64x64/apps/osm-kernels.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-kernels.desktop"
[Desktop Entry]
Type=Application
Name=Kernels
Comment=Install, remove and choose Linux kernels
Exec=osm-kernels
Icon=osm-kernels
Terminal=false
Categories=System;Settings;
Keywords=kernel;linux;mainline;liquorix;xanmod;grub;
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-kernels.desktop"


# ────────────────────────────────────────────────
# 6. Build OSM Settings + modules
# ────────────────────────────────────────────────
echo " "
echo "[8/10] Building osm-settings..."

cd "$ALT_ROOT/Alternix/apps/osm-settings" || { echo "ERROR: apps/osm-settings folder missing"; exit 1; }

g++ osm-settings.cpp -o osm-settings -fPIC -ldl $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m 755 osm-settings /usr/local/bin/

if [ -f "$ALT_ROOT/Alternix/icons/osm-settings.png" ]; then
    sudo cp "$ALT_ROOT/Alternix/icons/osm-settings.png" /usr/share/icons/hicolor/64x64/apps/osm-settings.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-settings.desktop"
[Desktop Entry]
Type=Application
Name=Settings
Comment=Settings App for Alternix / OSM-Phone
Exec=/usr/local/bin/osm-settings
Icon=osm-settings
Terminal=false
Categories=Utility;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-settings.desktop"

echo "• Building wifi.so..."
g++ -fPIC -shared wifi.cpp -o wifi.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m755 wifi.so /usr/local/bin/

echo "• Building bluetooth.so..."
g++ -fPIC -shared bluetooth.cpp -o bluetooth.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m755 bluetooth.so /usr/local/bin/

echo "• Building apps.so..."
g++ -fPIC -shared apps.cpp -o apps.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 apps.so /usr/local/bin/

echo "• Building mobile.so..."
g++ -fPIC -shared mobile.cpp -o mobile.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 mobile.so /usr/local/bin/

echo "• Building location.so..."
g++ location.cpp -o location.so -shared -fPIC -O2 $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 location.so /usr/local/bin/

echo "• Building date-time.so..."
g++ date-time.cpp -o date-time.so -shared -fPIC -O2 $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 date-time.so /usr/local/bin/

echo "• Building battery.so..."
g++ -fPIC -shared battery.cpp -o battery.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 battery.so /usr/local/bin/

echo "• Building emulation.so..."
g++ emulation.cpp -o emulation.so -shared -fPIC $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 emulation.so /usr/local/bin/

echo "• Building security.so..."
g++ -shared -fPIC security.cpp -o security.so `pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core`
sudo install -m755 security.so /usr/local/bin/

echo "• Building ethernet.so..."
g++ -fPIC -shared ethernet.cpp -o ethernet.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 ethernet.so /usr/local/bin/

echo "• Building display.so..."
g++ display.cpp -o display.so -shared -fPIC $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 display.so /usr/local/bin/

echo "• Building sound.so..."
g++ -std=c++17 -fPIC -shared sound.cpp -o sound.so `pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core`
sudo install -m755 sound.so /usr/local/bin/

echo "• Building kernel.so..."
g++ -std=c++17 -fPIC -shared kernel.cpp -o kernel.so `pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core`
sudo install -m755 kernel.so /usr/local/bin/

echo "• Building storage.so..."
g++ -fPIC -shared storage.cpp -o storage.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m755 storage.so /usr/local/bin/

echo "• Building accounts.so..."
g++ -std=c++11 accounts.cpp -o accounts.so -shared -fPIC $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 accounts.so /usr/local/bin/

echo "• Building system.so..."
g++ -fPIC -shared system.cpp -o system.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 system.so /usr/local/bin/

echo "• Building ui.so..."
g++ -fPIC -shared ui.cpp -o ui.so $(pkg-config --cflags --libs Qt5Widgets Qt5Gui Qt5Core)
sudo install -m755 ui.so /usr/local/bin/

echo "• Building reticulum.so..."
g++ -std=c++17 -Wall -Wextra -fPIC -shared -o reticulum.so reticulum.cpp $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m755 reticulum.so /usr/local/bin/reticulum.so

# ────────────────────────────────────────────────
# 6b. Build OSM Widgets (desktop widget overlay)
# ────────────────────────────────────────────────
echo " "
echo "[8/10] Building osm-widgets..."

cd "$ALT_ROOT/Alternix/apps/osm-widgets" || { echo "ERROR: apps/osm-widgets folder missing"; exit 1; }

sudo mkdir -p /usr/local/lib/alternix/widgets

g++ -fPIC osm-widgets.cpp -o osm-widgets -ldl $(pkg-config --cflags --libs Qt5Widgets) -lX11 -lXext -lXi
sudo install -m 755 osm-widgets /usr/local/bin/

echo "• Building osm-widgets-settings..."
g++ osm-widgets-settings.cpp -o osm-widgets-settings -fPIC -ldl $(pkg-config --cflags --libs Qt5Widgets)
sudo install -m 755 osm-widgets-settings  /usr/local/bin/

echo "• Building clock widget..."
g++ -I. -fPIC -shared widgets/clock.cpp -o clock.so $(pkg-config --cflags --libs Qt5Widgets)
sudo mv clock.so /usr/local/lib/alternix/widgets/

echo "• Building calendar widget..."
g++ -I. -std=c++11 -fPIC -shared widgets/calendar.cpp -o calendar.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -Dm755 calendar.so /usr/local/lib/alternix/widgets/calendar.so

echo "• Building 13-moon-calendar widget..."
g++ -I. -std=c++11 -fPIC -shared widgets/moon-calendar.cpp -o moon-calendar.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -Dm755 moon-calendar.so /usr/local/lib/alternix/widgets/moon-calendar.so

echo "• Building tzolkin widget..."
g++ -I. -std=c++11 -fPIC -shared widgets/tzolkin.cpp -o tzolkin.so $(pkg-config --cflags --libs Qt5Widgets)
sudo install -Dm755 tzolkin.so /usr/local/lib/alternix/widgets/tzolkin.so


if [ -f "$ALT_ROOT/Alternix/icons/osm-widgets.png" ]; then
    sudo cp "$ALT_ROOT/Alternix/icons/osm-widgets.png" /usr/share/icons/hicolor/64x64/apps/osm-widgets.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/osm-widgets.desktop"
[Desktop Entry]
Type=Application
Name=Widgets
Comment=Add and arrange widgets on the Alternix desktop
Exec=/usr/local/bin/osm-widgets-settings
Icon=osm-widgets
Terminal=false
Categories=Utility;
StartupNotify=false
EOF
chmod +x "$TARGET_HOME/.local/share/applications/osm-widgets.desktop"

# ────────────────────────────────────────────────
#            Custom App Shortcuts & Icons
# ────────────────────────────────────────────────
echo " "
echo "• Installing App Icons..."

cd "$ALT_ROOT/Alternix"

sudo install -Dm644 icons/*.png /usr/share/icons/hicolor/64x64/apps/

echo "• Creating htop.desktop launcher..."
sudo tee /usr/share/applications/htop.desktop >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=htop
Comment=System monitor
Exec=alacritty -e htop
Terminal=false
Icon=htop
Categories=System;
EOF

echo "• Creating fetch.desktop launcher..."
sudo tee /usr/share/applications/fetch.desktop >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=About
Comment=System monitor
Exec=alacritty -e fetch
Terminal=false
Icon=fetch
Categories=System;
EOF

echo "• Creating bauh Shortcut..."
sudo tee /usr/share/applications/bauh.desktop >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=Apps (bauh)
Comment=Application Manager
Exec=bauh
Icon=bauh
Categories=System;
EOF

echo "• Installing Alternix Updater..."
sudo install -m 755 "$ALT_ROOT/update/os-check-update" /usr/bin/
sudo install -D -m 644 "$ALT_ROOT/update/version.txt" /usr/share/alternix/version.txt


echo "• Creating Alternix Updater shortcut..."
sudo tee /usr/share/applications/os-check-update.desktop >/dev/null <<EOF
[Desktop Entry]
Name=System Update
Exec=alacritty -e /usr/bin/os-check-update
Icon=os-check-update
Type=Application
Terminal=false
Categories=System;
EOF



# ────────────────────────────────────────────────
# Create Brave YouTube WebApp launcher
# ────────────────────────────────────────────────
echo " "
echo "[System] Installing Brave WebApps..."

APP_DIR="$TARGET_HOME/.local/share/applications"
mkdir -p "$APP_DIR"

YOUTUBE_ICON="/usr/share/icons/hicolor/256x256/apps/youtube.png"
if [ -f "$ALT_ROOT/Alternix/icons/youtube.png" ]; then
    sudo cp "$ALT_ROOT/Alternix/icons/youtube.png" "$YOUTUBE_ICON"
fi

cat <<EOF > "$APP_DIR/youtube-webapp.desktop"
#!/usr/bin/env xdg-open
[Desktop Entry]
Version=1.0
Type=Application
Name=Youtube
Comment=Youtube WebApp (Brave)
Exec=brave-browser --app=https://www.youtube.com/ --new-window --disable-frame --force-device-scale-factor=1.3
Icon=youtube
Terminal=false
Categories=Network;WebBrowser;Utility;
StartupNotify=true
EOF
chmod +x "$APP_DIR/youtube-webapp.desktop"
echo "✓ YouTube WebApp installed."

echo "[Apps] Installing AlterniTech Forum WebApp..."
if [ -f "icons/alternitech-forum.png" ]; then
    sudo cp icons/alternitech-forum.png /usr/share/icons/hicolor/64x64/apps/alternitech-forum.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/alternitech-forums.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Alternitech Forums
Comment=Alternitech Community Forum WebApp (Brave)
Exec=brave-browser --app=https://alternitech.freeforums.net/ --new-window --force-device-scale-factor=1.3
Icon=alternitech-forum
Terminal=false
Categories=Network;WebBrowser;Utility;
StartupNotify=true
EOF
chmod +x "$TARGET_HOME/.local/share/applications/alternitech-forums.desktop"
echo "✓ Alternitech Forums WebApp installed."


echo "[Apps] Installing Breakout Game..."
if [ -f "extras/games/breakout.png" ]; then
    sudo cp "$ALT_ROOT/Alternix/extras/games/breakout.png" /usr/share/icons/hicolor/64x64/apps/breakout.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/breakout.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Breakout
Comment=Break the block game
Exec=brave-browser --app=file://$TARGET_HOME/extras/games/breakout.html --new-window --force-device-scale-factor=1.3
Icon=breakout
Terminal=false
Categories=Game;
StartupNotify=true
EOF
chmod +x "$TARGET_HOME/.local/share/applications/breakout.desktop"
echo "✓ Breakout Game installed."




echo "[Apps] Installing OpenStreetMap WebApp..."
if [ -f "icons/openmap.png" ]; then
    sudo cp icons/openmap.png /usr/share/icons/hicolor/64x64/apps/openmap.png
fi

cat <<EOF > "$TARGET_HOME/.local/share/applications/openmap.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=OpenStreetMap
Comment=OpenStreetMap WebApp (Brave)
Exec=brave-browser --app=https://openstreetmap.org/ --new-window --force-device-scale-factor=1.3
Icon=openmap
Terminal=false
Categories=Network;WebBrowser;Utility;
StartupNotify=true
EOF
chmod +x "$TARGET_HOME/.local/share/applications/openmap.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$TARGET_HOME/.local/share/applications" || true
fi
echo "• OpenStreetMap WebApp installed."


# ────────────────────────────────────────────────
# 7. Samba Network Updates
# ────────────────────────────────────────────────
echo " "
echo "• Updating /etc/samba/smb.conf..."
sudo sed -i '/workgroup = WORKGROUP/a client min protocol = NT1\nserver min protocol = NT1' /etc/samba/smb.conf

echo "• Restarting Samba service..."
# SysVinit: use service(8) instead of systemctl
sudo service smbd restart || true
sudo service nmbd restart || true


# ────────────────────────────────────────────────
# 8. OSM-Lockscreen Security Layer
# ────────────────────────────────────────────────
echo " "
echo "• Setting up lockscreen supervisor..."

# The lockscreen runs inside the user's own X session, started by
# osm-lockd from Qtile (login and resume) and from osm-power (Lock and
# Sleep). It used to also run as a system service under a separate
# "lockscreen" user, but that user had no access to the X display and
# `service` strips DISPLAY, so osm-lockscreen crashed on start and
# osm-lockd relaunched it every 0.05 s, forever. The service is gone.

# Install supervisor daemon (osm-lockd)
sudo tee /usr/local/bin/osm-lockd >/dev/null <<'LOCKD'
#!/bin/bash

# Only one lockscreen at a time. Waking and the Lock button can both
# start this, and a second copy would stack another lockscreen on top.
exec 9>"/tmp/osm-lockd-$(id -u).lock"
flock -n 9 || exit 0

FLAG="/tmp/osm_unlock_success"

while true; do
    rm -f "$FLAG"
    /usr/local/bin/osm-lockscreen 9>&-

    if [ -f "$FLAG" ]; then
        rm -f "$FLAG"
        # signal the user session (osm-status plays the boot sound once per boot)
        touch /tmp/osm_boot_unlocked 2>/dev/null
        chmod 666 /tmp/osm_boot_unlocked 2>/dev/null
        exit 0
    fi

    sleep 0.05
done
LOCKD
sudo chmod +x /usr/local/bin/osm-lockd

echo "[✓] Lockscreen supervisor installed."


# ────────────────────────────────────────────────
# 9. logind / elogind power key and sleep handling
# Devuan ships elogind as a drop-in for systemd-logind.
# Its config lives in /etc/elogind/logind.conf (same format).
# ────────────────────────────────────────────────
echo " "
echo "[X] Configuring elogind power key and sleep handling..."

sudo mkdir -p /etc/elogind/logind.conf.d /etc/elogind/sleep.conf.d

# Prevent unwanted tablet sleep from power/suspend keys, lid events and idle.
sudo tee /etc/elogind/logind.conf.d/alternix-power.conf >/dev/null <<'EOF'
[Login]
HandlePowerKey=ignore
HandleSuspendKey=ignore
HandleHibernateKey=ignore
HandleLidSwitch=ignore
HandleLidSwitchExternalPower=ignore
HandleLidSwitchDocked=ignore
IdleAction=ignore
EOF

# Disable elogind-managed suspend and hibernation on Devuan.
sudo tee /etc/elogind/sleep.conf.d/alternix-no-sleep.conf >/dev/null <<'EOF'
[Sleep]
AllowSuspend=no
AllowHibernation=no
AllowHybridSleep=no
AllowSuspendThenHibernate=no
EOF

# Also update the main logind.conf as a fallback for older elogind versions
# that don't support drop-in dirs
sudo sed -i 's/^#*HandlePowerKey=.*/HandlePowerKey=ignore/' /etc/elogind/logind.conf 2>/dev/null || true

sudo service elogind restart || true

echo "[✓] elogind configured."


# ────────────────────────────────────────────────
# 10. Autologin via agetty override
# Devuan uses /etc/inittab (SysVinit) rather than systemd drop-ins.
# We replace the tty1 line to pass --autologin.
# ────────────────────────────────────────────────
echo " "
echo "[5/10] Enabling autologin on tty1 for user $TARGET_USER..."

INITTAB="/etc/inittab"

if [ -f "$INITTAB" ]; then
    # Back up inittab before editing
    sudo cp "$INITTAB" "${INITTAB}.bak"

    # Replace the tty1 getty line with an autologin version.
    # Typical Devuan line:  1:2345:respawn:/sbin/getty 38400 tty1
    # We change it to use agetty with --autologin.
    if grep -q "^1:.*getty.*tty1" "$INITTAB"; then
        sudo sed -i "s|^1:.*getty.*tty1.*|1:2345:respawn:/sbin/agetty --autologin $TARGET_USER --noclear tty1 linux|" "$INITTAB"
        echo "• inittab tty1 line updated for autologin."
    else
        # Line not found in expected format — append a safe fallback
        echo "1:2345:respawn:/sbin/agetty --autologin $TARGET_USER --noclear tty1 linux" | sudo tee -a "$INITTAB" >/dev/null
        echo "• Autologin line appended to inittab."
    fi

    # Changes will apply on next boot. Never HUP PID 1 from a live-build
    # chroot, since it may refer to the build host's init process.
    if [ ! -e /etc/debian_chroot ] && [ -e /run/initctl ]; then
        sudo telinit q 2>/dev/null || true
    fi
else
    echo "WARNING: /etc/inittab not found."
    echo "If using OpenRC or runit, configure autologin in your getty service config."
    echo "For OpenRC: edit /etc/conf.d/agetty.tty1 and set agetty_options."
fi

sudo usermod -aG video,input "$TARGET_USER"

# ────────────────────────────────────────────────
# 11. Cleanup Alternix folder
# ────────────────────────────────────────────────

echo " "
# The source checkout is deliberately deleted here and replaced with a
# user-owned directory for third-party applications. Authentication is enabled
# only at the END of the installation, so retain the three source files in a
# private, root-owned staging directory before removing the checkout.
# Persist the sources in the installed system BEFORE deleting the checkout.
# This is needed especially for the live ISO: the initial desktop has no
# per-user pattern, so the installed-system updater must be able to enrol and
# activate authentication later without relying on a deleted source folder.
sudo install -d -o root -g root -m 0755 /usr/share/alternix/auth
for auth_file in alternix-auth-setup.sh alternix-auth.c osm-lock.cpp; do
    sudo install -o root -g root -m 0644 \
        "$ALT_ROOT/Alternix/apps/$auth_file" \
        "/usr/share/alternix/auth/$auth_file"
done
sudo chmod 0755 /usr/share/alternix/auth/alternix-auth-setup.sh

# Do not activate graphical authentication inside a live-build chroot.
if [ "$ALT_IS_LIVE_BUILD" != 1 ]; then
    echo "[Security] Preserving authentication sources before checkout cleanup..."
    ALT_AUTH_STAGE="$(sudo mktemp -d /var/tmp/alternix-auth.XXXXXXXX)"
    sudo chmod 0700 "$ALT_AUTH_STAGE"
    sudo install -o root -g root -m 0600 \
        "$ALT_ROOT/Alternix/apps/alternix-auth-setup.sh" "$ALT_AUTH_STAGE/alternix-auth-setup.sh"
    sudo install -o root -g root -m 0600 \
        "$ALT_ROOT/Alternix/apps/alternix-auth.c" "$ALT_AUTH_STAGE/alternix-auth.c"
    sudo install -o root -g root -m 0600 \
        "$ALT_ROOT/Alternix/apps/osm-lock.cpp" "$ALT_AUTH_STAGE/osm-lock.cpp"
fi

echo "[Cleanup] Removing Alternix source folder at $ALT_ROOT ..."
# Never remove the directory from which this shell is currently running.
cd /
rm -rf -- "$ALT_ROOT"

# Prepare a user-owned source checkout area for the third-party app installers.
# The old source repository and the new user checkout area are intentionally
# separate locations, even when the builder is running as root.
THIRD_PARTY_DIR="$TARGET_HOME/Alternix"
mkdir -p "$THIRD_PARTY_DIR"
chown "$TARGET_USER:$TARGET_GROUP" "$THIRD_PARTY_DIR"

# Download the AlternixOS release version from GitHub, and preserve it in
# the installed root filesystem as well as the selected user's home.
# Live ISO installations can create a DIFFERENT user after the ISO preview
# was built, so saving this file only in $TARGET_HOME is not sufficient.
echo "• Installing AlternixOS version..."
ALT_OS_VERSION_URL="https://raw.githubusercontent.com/DansDesigns/AlternixOS/main/version"
ALT_OS_VERSION_DEST="$TARGET_HOME/Alternix/version"
ALT_OS_VERSION_SYSTEM="/usr/share/alternix/os-version"
ALT_OS_VERSION_SKEL="/etc/skel/Alternix/version"
ALT_OS_VERSION_TMP="$(mktemp /tmp/alternixos-version.XXXXXX)"

# Download first, but permit an offline installation to reuse the version
# already bundled into the ISO. Do not accept an empty/HTML error response.
ALT_OS_VERSION_SOURCE=""
if curl -fL --show-error --silent --retry 3 --retry-delay 2 \
        --connect-timeout 10 --max-time 60 \
        --output "$ALT_OS_VERSION_TMP" "$ALT_OS_VERSION_URL" && \
        [ -s "$ALT_OS_VERSION_TMP" ] && \
        [ "$(wc -c < "$ALT_OS_VERSION_TMP")" -le 512 ] && \
        grep -q '[^[:space:]]' "$ALT_OS_VERSION_TMP" && \
        ! grep -Eqi '<(!doctype|html|head|body)' "$ALT_OS_VERSION_TMP"; then
    ALT_OS_VERSION_SOURCE="$ALT_OS_VERSION_TMP"
else
    echo "WARNING: Could not download AlternixOS version; checking for an ISO-bundled copy."
    for saved_version in "$ALT_OS_VERSION_SYSTEM" "$ALT_OS_VERSION_SKEL" "$ALT_OS_VERSION_DEST"; do
        if [ -s "$saved_version" ]; then
            ALT_OS_VERSION_SOURCE="$saved_version"
            break
        fi
    done
fi

if [ -z "$ALT_OS_VERSION_SOURCE" ]; then
    rm -f -- "$ALT_OS_VERSION_TMP"
    echo "ERROR: No AlternixOS version available from GitHub or the ISO." >&2
    echo "ERROR: Cannot finish an installation that has no AlternixOS version file." >&2
    exit 1
fi

# 1. Canonical system copy: survives a live ISO's squashfs-to-disk install.
#    Keep distinct from /usr/share/alternix/version.txt (AlternixDE updater).
sudo install -d -m 0755 /usr/share/alternix
if [ "$ALT_OS_VERSION_SOURCE" != "$ALT_OS_VERSION_SYSTEM" ]; then
    sudo install -m 0644 "$ALT_OS_VERSION_SOURCE" "$ALT_OS_VERSION_SYSTEM"
fi

# 2. User skeleton: useradd -m during the real OS installation inherits it.
sudo install -d -m 0755 /etc/skel/Alternix
sudo install -m 0644 "$ALT_OS_VERSION_SYSTEM" "$ALT_OS_VERSION_SKEL"

# 3. The user selected by this run (including a live-preview user).
sudo install -d -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0755 "$TARGET_HOME/Alternix"
sudo install -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0644 \
    "$ALT_OS_VERSION_SYSTEM" "$ALT_OS_VERSION_DEST"

# 4. Fallback for live installers that create user homes without /etc/skel,
#    or replace the home after copying the ISO. The first login restores the
#    bundled file to exactly ~/Alternix/version, WITHOUT needing internet or
#    overwriting a version that has since been updated.
sudo tee /etc/profile.d/alternixos-version.sh >/dev/null <<'ALT_OS_VERSION_PROFILE'
#!/bin/sh
ALT_OS_VERSION_FILE=/usr/share/alternix/os-version
if [ "$(id -u 2>/dev/null)" != 0 ] && [ -n "${HOME:-}" ] && \
   [ -d "$HOME" ] && [ -s "$ALT_OS_VERSION_FILE" ] && \
   [ ! -e "$HOME/Alternix/version" ] && [ ! -L "$HOME/Alternix/version" ]; then
    ( umask 022
      mkdir -p -- "$HOME/Alternix" &&
      cp -n -- "$ALT_OS_VERSION_FILE" "$HOME/Alternix/version"
    ) 2>/dev/null || :
fi
unset ALT_OS_VERSION_FILE
ALT_OS_VERSION_PROFILE
sudo chmod 0644 /etc/profile.d/alternixos-version.sh

if [ ! -s "$ALT_OS_VERSION_SYSTEM" ] || [ ! -s "$ALT_OS_VERSION_SKEL" ] || \
   [ ! -s "$ALT_OS_VERSION_DEST" ]; then
    echo "ERROR: AlternixOS version installation did not verify." >&2
    exit 1
fi

echo "• AlternixOS version: $(head -n 1 "$ALT_OS_VERSION_SYSTEM")"
echo "• Installed for $TARGET_USER at $ALT_OS_VERSION_DEST"
echo "• Bundled for installed users in $ALT_OS_VERSION_SYSTEM and $ALT_OS_VERSION_SKEL"
rm -f -- "$ALT_OS_VERSION_TMP"

# Build-time writes above must not leave the installed desktop owned by root.
for user_dir in "$TARGET_HOME/.config" "$TARGET_HOME/.local" \
                "$TARGET_HOME/.qtile_venv" "$TARGET_HOME/Pictures/wallpapers" \
                "$TARGET_HOME/extras"; do
    [ ! -e "$user_dir" ] || chown -R "$TARGET_USER:$TARGET_GROUP" "$user_dir"
done
for user_file in "$TARGET_HOME/.alacritty.toml" "$TARGET_HOME/.xinitrc" \
                 "$TARGET_HOME/.bash_profile" "$TARGET_HOME/.bashrc"; do
    [ ! -e "$user_file" ] || chown "$TARGET_USER:$TARGET_GROUP" "$user_file"
done

# Preserve existing clones when this installer is re-run.
clone_for_target() {
    local repo_url="$1" destination="$2"
    if [ -d "$destination/.git" ]; then
        echo "• Existing checkout found: $destination"
    elif [ -e "$destination" ]; then
        echo "ERROR: $destination already exists but is not a Git checkout."
        return 1
    else
        as_target git clone "$repo_url" "$destination"
    fi
}



# ────────────────────────────────────────────────
# 12. GLX compatibility check → patch picom.conf
# Detects whether the GPU supports GLX/OpenGL well
# enough for picom's glx backend. If not, switches
# picom.conf to xrender (safe on all hardware).
# ────────────────────────────────────────────────
echo " "
echo "•[Picom] Checking GLX compatibility..."

PICOM_CONF="$TARGET_HOME/.config/picom/picom.conf"
GLX_OK=false

# glxinfo must be available — install if missing
if ! command -v glxinfo >/dev/null 2>&1; then
    echo "• glxinfo not found, installing mesa-utils..."
    sudo apt install -y mesa-utils 2>/dev/null || true
fi

if command -v glxinfo >/dev/null 2>&1; then
    GL_RENDERER=$(glxinfo 2>/dev/null | grep "OpenGL renderer" | head -1)
    GL_VERSION=$(glxinfo 2>/dev/null | grep "OpenGL version" | head -1)

    echo "• Renderer : $GL_RENDERER"
    echo "• Version  : $GL_VERSION"

    # Extract the major OpenGL version number
    GL_MAJOR=$(echo "$GL_VERSION" | grep -oP 'OpenGL version string: \K[0-9]+' | head -1)

    # GLX backend requires OpenGL 2.0+ and a real renderer (not software/llvm)
    if [[ "$GL_MAJOR" -ge 2 ]] 2>/dev/null && \
       ! echo "$GL_RENDERER" | grep -qiE "llvmpipe|softpipe|software|swrast|virgl"; then
        GLX_OK=true
    fi
else
    echo "• glxinfo unavailable — assuming GLX not supported."
fi

if [ "$GLX_OK" = true ]; then
    echo "[✓] GLX compatible — picom will use glx backend."
else
    echo "[!] GLX not supported or too limited — switching picom to xrender backend."

    if [ -f "$PICOM_CONF" ]; then
        # Replace backend line if it exists
        if grep -q "^backend" "$PICOM_CONF"; then
            sed -i 's/^backend\s*=\s*"glx"/backend = "xrender"/' "$PICOM_CONF"
            sed -i 's/^backend\s*=\s*"egl"/backend = "xrender"/' "$PICOM_CONF"
        else
            # Prepend if no backend line found
            sed -i '1s/^/backend = "xrender";\n/' "$PICOM_CONF"
        fi

        # Disable vsync — unreliable with xrender on old Intel
        if grep -q "^vsync" "$PICOM_CONF"; then
            sed -i 's/^vsync\s*=\s*true/vsync = false/' "$PICOM_CONF"
        else
            echo "vsync = false;" >> "$PICOM_CONF"
        fi

        echo "[✓] picom.conf patched: backend = xrender, vsync = false"
    else
        echo "• $PICOM_CONF not found — creating minimal xrender config..."
        mkdir -p "$(dirname "$PICOM_CONF")"
        cat <<'PICOMCFG' > "$PICOM_CONF"
# picom config — xrender backend (auto-set: GLX not supported on this GPU)
backend = "xrender";
vsync = false;
PICOMCFG
        echo "[✓] Minimal xrender picom.conf created."
    fi
fi

# The installer may have written picom.conf as root while in the ISO chroot.
if [ -e "$PICOM_CONF" ]; then
    chown "$TARGET_USER:$TARGET_GROUP" "$PICOM_CONF"
fi

# ────────────────────────────────────────────────
# 13. 3D animated fetch (areofyl/fetch - used as "About")
# ────────────────────────────────────────────────
echo " "
echo "[SYSTEM] Starting 3rd Party Software Install... "
echo " "
echo "• Installing fetch (areofyl/fetch)..."
# Build fetch in temporary space; no dependence on $HOME or ALT_ROOT.
(
    set -e
    cd /
    FETCH_BUILD="$(mktemp -d /tmp/alternix-fetch.XXXXXX)"
    trap 'rm -rf -- "$FETCH_BUILD"' EXIT
    git clone --depth 1 https://github.com/areofyl/fetch.git "$FETCH_BUILD/fetch"
    make -C "$FETCH_BUILD/fetch"
    if [ "$(id -u)" -eq 0 ]; then
        make -C "$FETCH_BUILD/fetch" install
    else
        sudo make -C "$FETCH_BUILD/fetch" install
    fi
)
echo "[✓] 3D fetch Installed..."


# ──────────────────────────────────────────────── 
# 14. install rounded-corners
# ────────────────────────────────────────────────
echo " "

echo "• Installing rounded-corners..."
clone_for_target https://github.com/DansDesigns/rounded_corners "$THIRD_PARTY_DIR/rounded_corners"
cd "$THIRD_PARTY_DIR/rounded_corners"
chmod +x install_corners.sh
sudo ./install_corners.sh
echo "[✓] Rounded-Corners Installed..."


# ──────────────────────────────────────────────── 
# 15. install Merlin
# ────────────────────────────────────────────────
#echo " "
#echo "• Installing Merlin Browser..."
#clone_for_target https://github.com/DansDesigns/merlin-browser "$THIRD_PARTY_DIR/merlin-browser"
#cd "$THIRD_PARTY_DIR/merlin-browser"
#chmod +x install.sh
#as_target ./install.sh
#echo "[✓] Merlin Browser Installed..."



# ────────────────────────────────────────────────
# 16. auto-cpufreq
# ────────────────────────────────────────────────
echo " "
echo "• Installing auto-cpufreq..."
clone_for_target https://github.com/AdnanHodzic/auto-cpufreq.git "$THIRD_PARTY_DIR/auto-cpufreq"
cd "$THIRD_PARTY_DIR/auto-cpufreq"
sudo ./auto-cpufreq-installer
sudo auto-cpufreq --install
echo "[✓] auto-cpufreq Installed..."


# ────────────────────────────────────────────────
# 17. Freehand Spatial Desktop
# ────────────────────────────────────────────────
#echo " "
#echo "• Installing Freehand Spatial Desktop..."
# Clone explicitly into lowercase 'hands' (Git would otherwise use 'Hands').
#clone_for_target https://github.com/DansDesigns/Hands.git "$THIRD_PARTY_DIR/hands"
#cd "$THIRD_PARTY_DIR/hands"
#chmod +x install_linux.sh
#as_target ./install_linux.sh
#echo "[✓] Freehand Spatial Desktop Installed..."


# ────────────────────────────────────────────────
# 18. Wave PLayer
# ────────────────────────────────────────────────
#echo " "
#echo "• Installing Wave Music Player.."
#clone_for_target https://github.com/DansDesigns/music_player "$TARGET_HOME/music_player"
#cd "$TARGET_HOME/music_player"
#chmod +x install_music_player.sh
#as_target ./install_music_player.sh
#echo "[✓] Wave PLayer Installed..."
#cd /


# Final Nala check: a later package operation must not leave the updater broken.
if ! command -v nala >/dev/null 2>&1 || ! nala --version >/dev/null 2>&1; then
    echo "[System] Nala is no longer available; attempting to restore it.."
    if ! sudo apt-get install -y nala || \
       ! command -v nala >/dev/null 2>&1 || ! nala --version >/dev/null 2>&1; then
        echo "ERROR: Nala is unavailable at the end of installation. System Update would not work."
        exit 1
    fi
fi

# ────────────────────────────────────────────────
# AlternixOS terminal policy: remove xterm + uxterm and use Alacritty.
# Run after all package operations, so dependencies cannot pull xterm back
# into this installation/update. Do not autoremove unrelated X11 packages.
# ────────────────────────────────────────────────
echo "[Terminal] Enforcing Alacritty as the default terminal..."
if ! command -v alacritty >/dev/null 2>&1; then
    sudo apt-get install -y alacritty
fi
ALTERNIX_ALACRITTY="$(command -v alacritty || true)"
if [ -z "$ALTERNIX_ALACRITTY" ] || [ ! -x "$ALTERNIX_ALACRITTY" ]; then
    echo "ERROR: Alacritty is unavailable; refusing to remove the existing terminal." >&2
    exit 1
fi

if dpkg-query -W -f='${Status}' xterm 2>/dev/null | grep -qx 'install ok installed'; then
    # Make sure the purge would NOT remove any other packages (e.g. an X server).
    if ! ALT_XTERM_SIMULATION="$(sudo apt-get -s purge xterm)"; then
        echo "ERROR: Could not safely simulate removing xterm." >&2
        exit 1
    fi
    ALT_XTERM_EXTRA_REMOVALS="$(printf '%s\n' "$ALT_XTERM_SIMULATION" | awk '$1 == "Remv" && $2 != "xterm" {print $2}')"
    if [ -n "$ALT_XTERM_EXTRA_REMOVALS" ]; then
        echo "ERROR: Purging xterm would also remove: $ALT_XTERM_EXTRA_REMOVALS" >&2
        echo "Refusing to remove other packages. Check the x-terminal-emulator dependencies." >&2
        exit 1
    fi
    sudo env DEBIAN_FRONTEND=noninteractive apt-get purge -y xterm
fi

# Register Alacritty even if this package version did not register itself.
sudo update-alternatives --install /usr/bin/x-terminal-emulator \
    x-terminal-emulator "$ALTERNIX_ALACRITTY" 80
sudo update-alternatives --set x-terminal-emulator "$ALTERNIX_ALACRITTY"

if dpkg-query -W -f='${Status}' xterm 2>/dev/null | grep -qx 'install ok installed'; then
    echo "ERROR: The xterm package is still installed." >&2
    exit 1
fi
if [ "$(readlink -f /usr/bin/x-terminal-emulator)" != "$(readlink -f "$ALTERNIX_ALACRITTY")" ]; then
    echo "ERROR: x-terminal-emulator does not resolve to Alacritty." >&2
    exit 1
fi
echo "[Terminal] xterm/uxterm removed; x-terminal-emulator -> $ALTERNIX_ALACRITTY"

# Activate sudo PAM only after every other installation step succeeds.
# A live-build chroot has no interactive user and must NOT enrol a shared,
# factory-set administrator pattern. Installed systems enrol their own pattern.
# Never retain the temporary NOPASSWD: ALL rule in the finished live image.
if [ "$ALT_IS_LIVE_BUILD" = 1 ]; then
    echo "[Security] ISO prebuild: deferring interactive pattern/PIN enrolment."
    echo "[Security] Retaining standard sudo/PAM until installed-system setup."
    sudo rm -f /etc/sudoers.d/alternix-nopasswd
    ALT_TEMP_NP_ACTIVE=0
else
    echo "[Security] Activating Alternix graphical sudo authentication..."
    if [ -z "$ALT_AUTH_STAGE" ]; then
        echo "ERROR: Authentication sources were not staged before checkout cleanup." >&2
        exit 1
    fi
    # Keep the staging directory private (0700, root-owned) until setup exits.
    # A root shell performs cleanup even after PAM has been activated, so no
    # second graphical sudo prompt is required just to delete the stage.
    # The setup script tests the pattern window first, switches PAM only
    # provisionally, and restores the saved sudo/PAM configuration on failure.
    if ! sudo bash -c '
        stage="$1"; login_user="$2"
        cleanup_auth_stage() { rm -rf -- "$stage"; }
        trap cleanup_auth_stage EXIT
        bash "$stage/alternix-auth-setup.sh" "$login_user" "$stage"
    ' _ "$ALT_AUTH_STAGE" "$TARGET_USER"; then
        echo "ERROR: Alternix graphical sudo authentication failed verification; old PAM configuration restored." >&2
        exit 1
    fi
    ALT_AUTH_STAGE=""
    ALT_TEMP_NP_ACTIVE=0
fi

# ────────────────────────────────────────────────
# Finish + prompt
# ────────────────────────────────────────────────
echo " "
echo " "
echo " "
echo " "
echo "=============================================="
echo "     Alternix installation complete!"
echo "     (Devuan / SysVinit Edition)"
echo "=============================================="
echo " "
echo ""
echo "Everything installed to /usr/local/bin/"
echo ""
echo "Autologin + startx enabled for user: $TARGET_USER"
echo ""
echo ".xinitrc configured for Qtile."
echo ""
echo "Init system: SysVinit  |  logind: elogind"
if [ "${ALT_AUDIO_SETUP_FAILED:-0}" = 1 ]; then
    echo "WARNING: Audio provisioning is incomplete; consult /var/log/alternix/."
fi
echo ""
echo "Press 1 to Restart"
echo "Press 2 to Continue"
echo ""

while true; do
    read -n 1 -s -r KEY
    if [[ "$KEY" == "1" ]]; then
        echo "Beginning Reboot Sequence..."
        echo " "
        echo "This window will self-destruct in 5 seconds..."
        sleep 1; echo "5.."
        sleep 1; echo "4.."
        sleep 1; echo "3.."
        sleep 1; echo "2.."
        sleep 1; echo "1.."
        sleep 1
        if (( EUID == 0 )); then
            reboot
        elif command -v loginctl >/dev/null 2>&1; then
            loginctl reboot || echo "Please reboot from the System Power menu."
        else
            echo "Please reboot from the System Power menu."
        fi
        break
    elif [[ "$KEY" == "2" ]]; then
        echo ""
        echo "Continuing to shell..."
        break
    else
        echo ""
        echo "Invalid choice. Press 1 to Restart or 2 to Continue."
    fi
done
