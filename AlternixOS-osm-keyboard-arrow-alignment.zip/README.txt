AlternixOS osm-keyboard — fixed Up-arrow alignment in symbols mode

Updated files:
  Alternix/apps/osm-keyboard.h (symbol-row key order corrected)
  Alternix/apps/osm-keyboard.cpp (identical to last Super/modifier-lock release)

Full keyboard / ?123 mode now places row-3 Up at column 10
(grid columns 20-21), directly above row-4 Down.
The punctuation keys previously surrounding Up are now ... ? < > Up.
The letter layout, Super/Shift/Ctrl locks, auto-show and region layouts
are unchanged. No installer/updater modifications are needed.

Replace both files in Alternix/apps/ and run your existing updater.
The C++ build cannot be executed here without Qt5/AT-SPI development libs.
